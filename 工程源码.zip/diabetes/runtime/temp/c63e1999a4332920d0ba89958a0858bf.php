<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp\www\diabetes\public/../application/index\view\knowledge\knowledge5.html";i:1555309888;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病患者需要控制喝水吗？患者身体缺水及时补水</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病知识</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('knowledge'); ?>">返回首页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                    <li ><a href="<?php echo url('myinfo'); ?>">我的信息</a></li>
                    <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>     
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病患者需要控制喝水吗？患者身体缺水及时补水</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-3" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/5.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p >
 </br>
 </br>
    身体缺水的九种表现，小便颜色深黄、便秘经常会认识为身体缺水的表现，其实身体缺水还有很多表现形式，看看你是不是缺水了呢。尤其糖尿病人要注意及时补水，以利于新陈代谢和降糖。不要忌讳三多，要关注饮水问题。</br>
 
　　一，口腔干燥舌头肿胀：身体缺水的第一信号是口渴。脱水会导致口干和舌头轻微肿胀，所以夏季要及时喝水。</br>
 
　　二，小便深黄色：随着血压下降和身体组织缺水，脱水者的肾脏会浓缩尿液甚至阻止尿液产生。尿液浓度随之增加，其颜色也会逐步加深，严重时呈深黄色甚至琥珀色。</br>
 
　　三，便秘：当肠道吸收过量水分时，就会发生便秘。身体一旦缺水，肠道就会吸收更多水分予以补充体液，从而导致大便干结。</br>
 
　　四，皮肤缺乏弹性：脱水会降低皮肤弹性。医生通过“挤捏试验”快速检查皮肤弹性，判断病人是否脱水。</br>
 
　　五，头晕目眩：除了血流量和血压下降之外，脱水也会导致头晕目眩。其中一大关键信号就是快速站起时，突然头昏眼花。</br>
 
　　六，疲惫：长期缺水容易导致血流量和血压下降，血液含氧量也随之下降。缺少足量氧气，肌肉和神经功能就会削弱，因而更容产生疲劳感。</br>
 
　　七，没有眼泪：纵然大声哭喊也没有一滴眼泪，那么身体肯定缺水。</br>
 
　　八，心悸：心脏与身体其他肌肉一样，脱水造成的血流量减少和电解质变化会导致心悸。</br>
 
　　九，肌肉痉挛：长期缺水会造成身体电解质失调，导致运动中或运动后持续性肌肉痉挛。</br>
 </p>
</div>
<div style="margin-left:5%;">
上一篇：<a href="<?php echo url('knowledge4'); ?>">吃甜食多就会得糖尿病吗？糖尿病患者还能吃甜食吗？</a>、</br>
下一篇：<a href="<?php echo url('knowledge6'); ?>">糖尿病患者需要补硒吗？常吃含硒高的食物有益于健康</a> </br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>