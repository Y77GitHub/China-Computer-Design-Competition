<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"C:\wamp\www\diabetes\public/../application/index\view\information\myinfo.html";i:1556539365;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>个人信息</title>
		<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
		<link href="/diabetes/public/static/css/index.css" rel="stylesheet" type="text/css" >
		<link href="/diabetes/public/static/css/style.css" rel="stylesheet" type="text/css" media="all" />		
		<script type="text/javascript" src="/diabetes/public/static/js/jquery.min.js"></script>
		<script src="/diabetes/public/static/js/echarts.js"></script>
		<script src="/diabetes/public/static/js/easyResponsiveTabs.js" type="text/javascript"></script>
	</head>
	<body>
		<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
  	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse" > <span class="sr-only" >切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
  	<img src="/diabetes/public/static/images/logo.jpg" class="logostyle" />
    <a class="navbar-brand" id="biaotistyle3" >糖友之家</a> 
</div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse"  style="border-top-color:#fff;">
  <ul class="nav navbar-nav">
    <li><a href="<?php echo url('information'); ?>">返回首页</a></li> 
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="background-color: #7FD9D6;">
                    <h style="color:#595d5d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu" >
                 
                  <li ><a  href="<?php echo url('logout'); ?>" style="color: #595d5d;">退出</a></li> 
                </ul>
  </li>   

     
    <?php endif; ?>
</ul>
</nav>
		<!--导航条结束-->
		<div class="main">
			<div class="content">
				
				<div class="sap_tabs">
					<h2>个人信息</h2>
					<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
						<div class="portfolio-grid">
							<!-- 左侧框 -->
							<div class="port-left">
								<ul class="resp-tabs-list">	
									  <li class="resp-tab-item" aria-controls="tab_item-0" role="tab"><span>基本信息</span></li>	
									  <li class="resp-tab-item" aria-controls="tab_item-4" role="tab"><span>修改密码</span></li>		
									  <li class="resp-tab-item" aria-controls="tab_item-2" role="tab"><span>饮食记录</span></li>
									  <li class="resp-tab-item" aria-controls="tab_item-3" role="tab"><span>身体指标</span></li>
								</ul>		
							</div>
							<!-- 右侧框开始 -->
							<div class="port-right">	
								<div class="resp-tabs-container">
									<!-- 基本信息 -->
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
										<div class="profile-content">
											    <form action="<?php echo url('setpeople'); ?>" method="post" enctype="multipart/form-data">
												<img class="lady"  src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" id="img_driver" onclick="driverUpload()"/></br>
												<input name="head_sculpture" type="file" id="input_upload_driver" style="display: none" accept="image/jpg, image/png, image/jpeg" onChange="preview(this,'img_driver');">
									  			<div class="clear"></div>
									            <h4>我的头像</h4>  

												<h3>年龄(岁)</h3>
												<div class="email-group">
													<div class="age-icon"><span></span></div>
													<div class="email-form">
														<input type="text" name="age" class="form-control1" value="<?php echo $data['age']; ?>">	
													</div>
													<div class="clear"></div>
												</div>
												<h3>身高(cm)</h3>	
												<div class="phone-group">			
													<div class="height-icon"><span></span></div>
													<div class="cell-form">
														<input type="text" name="height" class="form-control1" value="<?php echo $data['height']; ?>">
													</div>
													<div class="clear"></div>					 
												</div>
												<h3>体重(kg)</h3>	
												<div class="phone-group">			
													<div class="weight-icon"><span></span></div>
													<div class="cell-form">											
														<input type="text" name="weight" class="form-control1" value="<?php echo $data['weight']; ?>">
													</div>
													<div class="clear"></div>					 
												</div>
												<h3>性别</h3>	
												<div class="radio-btns">
													<div class="swit">								
														<div class="check_box"> 
															<div class="radio"> 
																<label><input type="radio" name="sex" value="男" checked="checked"/><i></i><img src="/diabetes/public/static/images/man.png" alt=" "/>
																</label> 
															</div>
														</div>
														<div class="check_box"> 
															<div class="radio2"> 
																<label><input type="radio" name="sex" value="女" /><i></i><img src="/diabetes/public/static/images/woman.png" alt=" "/>
																</label> 

															</div><div class="clear"></div>

														</div>	

													</div>													
																
												</div>
												<div class="update"><button type="submit" class="btn btn-primary">修改</button>
												</div>
											</form>
										</div>
									</div>
									<!-- 修改密码 -->
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-4">
										<div class="work-play">
											<form action="<?php echo url('setpassword'); ?>" method="post">
												<h4>新密码</h4>												
												<input  style="width: 85%" id="password" type="password" name="password" class="form-control1 well" placeholder="请输入新密码" onkeyup="validate1()"/>
                                                </br>	

												<span id="tishi1"></span>										
												<h4>确认密码</h4>												
												<input style="width: 85%" id="repassword" type="password" name="repassword" class="form-control1 well" placeholder="请再次输入新密码" onkeyup="validate()"/>
                                                </br>
												<span id="tishi"></span>
												<div class="clear"></div>
										</div>	
										<div class="update"><button type="submit" class="btn btn-primary">修改</button></div>
										<div class="clear"></div>
                                             </form>
									</div>
									<!-- 饮食记录 -->
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-2">
										<div class="social-life">
											<div  class="social-life1">
											<form action="<?php echo url('setdiet_record'); ?>" method="post">	
                 								<h5 style="  margin-left:1%;">请选择日期(<strong style="font-size: 25px;">必填</strong>):</h5>
                								<input type="text"  style="margin-left:1%;" name="time1" onclick="SelectDate(this,'yyyy-MM-dd')" value="<?php echo $data['time1']; ?>"/>
                								<button type="submit"> 确定 </button>
                                                </form>										
												<a  class="file" style="margin-top: 30px;"><input TYPE="button" onclick="addContent1()">早餐</a>
												<a  class="file"><input TYPE="button" onclick="addContent2()">中餐</a>
												<a  class="file"><input TYPE="button" onclick="addContent3()">晚餐</a>
												<a  class="file"><input TYPE="button" onclick="addContent4()">加餐</a>
											</div>
											<div class="social-life2">
												<div id="box1" style="width: 100%;"></div>
												<div id="box2"></div>
											</div>										
										</div>
									</div>	
									<!-- 身体指标 -->
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-4">
										<div class="work-play">
											<form action="<?php echo url('setbody_index'); ?>" method="post">
											<h5>请选择日期(<strong style="font-size: 25px;">必填</strong>):</h5>
           									<input type="text" name="time2" onclick="SelectDate(this,'yyyy-MM-dd')" value="<?php echo $data['time2']; ?>"/>
			 								<!-- 为ECharts准备一个具备大小（宽高）的Dom -->
			 								<button type="submit"> 确定 </button>
    										<div id="zhexian"></div>
    										</form>
    									</div>	
									</div>	
								</div><!-- resp-tabs-container结束 -->	
							</div><!-- 右侧框结束 -->
						</div><!-- portfolio-grid结束 -->
					</div><!--horizontalTab结束 -->
				</div><!-- sap_tabs结束 -->
			</div><!-- content结束 -->
		</div><!-- main结束 -->
		<script>
    function addContent1(){
        var oDiv1=document.getElementById("box1");
        var oDiv2=document.getElementById("box2");
        if(oDiv1==null && oDiv2==null){
        	oDiv1.innerHTML="该日期没有早餐记录";
        	oDiv2.innerHTML="该日期没有早餐记录";
        }else{
        	oDiv1.innerHTML="<?php echo $data['breakfast_record']; ?>";
        	oDiv2.innerHTML='<img src="/diabetes/public/breakfast_images/<?php echo $data['breakfast_images']; ?>"/>';   //添加图片
        }
        
    }
    function addContent2(){
        var oDiv1=document.getElementById("box1");
        var oDiv2=document.getElementById("box2");
        if(oDiv1==null && oDiv2==null){
        	oDiv1.innerHTML="该日期没有午餐记录";
        	oDiv2.innerHTML="";
        }else{
        	oDiv1.innerHTML="<?php echo $data['lunch_record']; ?>";
        	oDiv2.innerHTML='<img src="/diabetes/public/lunch_images/<?php echo $data['lunch_images']; ?>"/>';   //添加图片
        }
        
    }
    function addContent3(){
        var oDiv1=document.getElementById("box1");
        var oDiv2=document.getElementById("box2");
        if(oDiv1==null && oDiv2==null){
        	oDiv1.innerHTML="该日期没有晚餐记录";
        	oDiv2.innerHTML="";
        }else{
        	oDiv1.innerHTML="<?php echo $data['dinner_record']; ?>";
        	oDiv2.innerHTML='<img src="/diabetes/public/dinner_images/<?php echo $data['dinner_images']; ?>"/>';   //添加图片
        }
    }
    function addContent4(){
        var oDiv1=document.getElementById("box1");
        var oDiv2=document.getElementById("box2");
        if(oDiv1==null && oDiv2==null){
        	oDiv1.innerHTML="该日期没有加餐记录";
        	oDiv2.innerHTML="";
        }else{
        	oDiv1.innerHTML="<?php echo $data['extra_meal_record']; ?>";
        	oDiv2.innerHTML='<img src="/diabetes/public/extra_meal_images/<?php echo $data['extra_meal_images']; ?>"/>';   //添加图片
        }
    }
</script>
<script type="text/javascript">
	/**
 * 文件上传
 */
function driverUpload() {
    $('#input_upload_driver').click(); // 模拟文件上传按钮点击操作
}

/**
 * 缩略图预览
 * @param file
 * @param container
 */
var preview = function(file, container){
    //缩略图类定义
    var Picture  = function(file, container){
        var height = 0,
            width  = 0,
            ext    = '',
            size   = 0,
            name   = '',
            path   =  '';
        var self   = this;
        if(file){
            name = file.value;
            if(window.navigator.userAgent.indexOf("MSIE")>=1){
                file.select();
                path = document.selection.createRange().text;
            }else {
                if(file.files){
                    // path =  file.files.item(0).getAsDataURL(); // firefox7.0之后该方法弃用了，用下面那个
                    path = window.URL.createObjectURL(file.files[0]);
                }else{
                    path = file.value;
                }
            }
        }else{
            throw '无效的文件';
        }
        ext = name.substr(name.lastIndexOf("."), name.length);
        if(container.tagName.toLowerCase() != 'img'){
            throw '不是一个有效的图片容器';
            container.visibility = 'hidden';
        }
        container.src = path;
        container.alt = name;
        container.style.visibility = 'visible';
        height = container.height;
        width  = container.width;
        size   = container.fileSize;
        this.get = function(name){
            return self[name];
        };
        this.isValid = function(){
            if(allowExt.indexOf(self.ext) !== -1){
                throw '不允许上传该文件类型';
                return false;
            }
        }
    };

    try{
        var pic =  new Picture(file, document.getElementById('' + container));
    }catch(e){
        alert(e);
    }
};
</script>
	    <script type="text/javascript">
	        // 基于准备好的dom，初始化echarts实例
	        var myChart = echarts.init(document.getElementById('zhexian'));

	        // 指定图表的配置项和数据
	        var option = {
			    title: {
			        text: '  用户一天血糖变化',
			        //subtext: '纯属虚构'
			    },
			    tooltip: {
			        trigger: 'axis'
			    },
			    legend: {
			        data:['血糖浓度']
			    },

			    toolbox: {
			        show: true,
			        feature: {
			            dataZoom: {
			                yAxisIndex: 'none'
			            },
			            dataView: {readOnly: false},
			            magicType: {type: ['line', 'bar']},
			            restore: {},
			            saveAsImage: {}
			        }
			    },
			    xAxis:  {
			        type: 'category',
			        boundaryGap: true,
			        data: ['早饭前','早饭后','中饭前','中饭后','晚饭前','晚饭后','睡觉前']
			    },
			    
			    yAxis: {
			        type: 'value',
			        axisLabel: {
			            formatter: '{value}mmol/L'
			        }
			    },
			    series: [
			        {
			            name:'血糖浓度',
			            type:'line',
			             color: ['#65a9c6'],
			            data:[<?php echo $data['breakfast_before']; ?>,<?php echo $data['breakfast_after']; ?>,<?php echo $data['lunch_before']; ?>,<?php echo $data['lunch_after']; ?>,<?php echo $data['dinner_before']; ?>,<?php echo $data['dinner_after']; ?>,<?php echo $data['extra_meal_before']; ?>,<?php echo $data['extra_meal_after']; ?>,<?php echo $data['sleep']; ?>],
			            markPoint: {
			                data: [
			                    // {name: '最低', value: -2, xAxis: 1, yAxis: -1.5}
			                    {type: 'max', name: '最大值'},
			                    {type: 'min', name: '最小值'}
			                ]
			            },
			            markLine: {
			                data: [
			                    {type: 'average', name: '平均值'},

			                    [{
			                        symbol: 'none',
			                        x: '90%',
			                        yAxis: 'max'
			                    }, {
			                        symbol: 'circle',
			                        label: {
			                            normal: {
			                                position: 'start',
			                                formatter: '最大值'
			                            }
			                        },
			                        type: 'max',
			                        name: '最高点'
			                    }],
			                    [{
			                        symbol: 'none',
			                        x: '90%',
			                        yAxis: 'min'
			                    }, {
			                        symbol: 'circle',
			                        label: {
			                            normal: {
			                                position: 'start',
			                                formatter: '最小值'
			                            }
			                        },
			                        type: 'min',
			                        name: '最低点'
			                    }]
			                ]
			            }
			        }
			    ]
			};


	        // 使用刚指定的配置项和数据显示图表。
	        myChart.setOption(option);
	        //根据窗口的大小变动图表 --- 重点
// window.onresize = function(){
//     myChart.resize();
// }
	    </script>
<script>
function validate1(){
  var pwd1 = document.getElementById("password").value;
  // 设置的密码是否符合
    if(pwd1.length<=0){
      document.getElementById("tishi1").innerHTML="<font color='red'>密码不能为空</font>";
      document.getElementById("button").disabled = true;
    }else if(pwd1.length<6){
      document.getElementById("tishi1").innerHTML="<font color='red'>密码长度小于6位</font>";
      document.getElementById("button").disabled = true;
    }else if(pwd1.length>12){
      document.getElementById("tishi1").innerHTML="<font color='red'>密码长度小于12位</font>";
      document.getElementById("button").disabled = true;
    }else{
      document.getElementById("tishi1").innerHTML="<font color='green'>密码长度正确</font>";
      document.getElementById("button").disabled = false;
    }
}
function validate() {
    var pwd1 = document.getElementById("password").value;
    var pwd2 = document.getElementById("repassword").value;
    
<!-- 对比两次输入的密码 -->
    if(pwd2.length<=0){
      document.getElementById("tishi").innerHTML="<font color='red'>确认密码不能为空</font>";
      document.getElementById("button").disabled = true;
    }else if(pwd1 == pwd2){
        document.getElementById("tishi").innerHTML="<font color='green'>两次密码一致</font>";
        document.getElementById("button").disabled = false;
    }else {
        document.getElementById("tishi").innerHTML="<font color='red'>两次密码不一致</font>";
        document.getElementById("button").disabled = true;
    }
}
</script>
<script> 
   $("input:radio[value=<?php echo $data['sex']; ?>]").attr('checked','true');
</script>
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
	</body>
</html>