<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information3.html";i:1556207373;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body style="background-color: #d6ecf0">
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>   
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">礼来糖尿病领域再发力与Adocia合作研发“超速效胰岛素”</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/information3.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p style="font-size:16px;">
 </br>
 </br>
   近日，礼来与法国生物技术公司Adocia签署合作协议，决定联手研发一种名为BioChaperone Lispro的超速效胰岛素，用于治疗1型和2型糖尿病。</br>
 
　　Adocia首先会获得5千万美元的预付款，并且在研发和管理过程中将会获得2.8亿美元，此外，从销售和使用权方面又可以获得2.4亿美元。除了这些收益以外，礼来还会给予Adocia一定的研发补偿，以及承担后期研发、制造和销售的相关责任。</br>
 
　　礼来和Adocia将会联合研发，目前已经进入到1期临床试验阶段，目的是能够使患者餐后保持较平稳的血糖浓度。BioChaperone Lispro的优势之一是胰岛素注射时间的灵活性大大增强，减小餐后血糖浓度波动的范围，降低低血糖症的发病率，从整体上实现血糖浓度的控制。</br>
 
　　礼来是糖尿病治疗领域的巨头，从1923年推出第一支商业化胰岛素以来，就一直致力于糖尿病的治疗。目前，礼来拥有顶尖的糖尿病治疗药物——Humalog和Humulin，在GEN出具的榜单中，分列第4名和第10名。</br>
 
　　此外，礼来去年宣布投资7亿多美元加强在波多黎各、法国和中国的产能，并且建立位于印第安纳波利斯的分部。</br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>