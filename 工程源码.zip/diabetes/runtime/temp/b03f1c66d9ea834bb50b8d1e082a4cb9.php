<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"C:\wamp\www\diabetes\public/../application/index\view\tool\basicmetabolismcalculation.html";i:1556279316;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>基础代谢计算</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
<style type="text/css">
/* 媒体查询开始 */
    @media only screen and (max-width:767px){
       
    #tool-content{
     float:left; margin-top:3.5%; height:40%; 
    }
    .image-content{width:80%; height:180px; overflow:hidden; margin-left: 10%; margin-right:10%;}
    .button-content{ width: 48px; float: left; margin-left: 23%; margin-top:5%;}

    }


    @media only screen and (min-width:1200px){
         #tool-content{
     float:left; margin-top:3.5%; height:30%;
    }
    .yszn{width:90%; height:500px; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; }
       .image-content{width:100%; height:135px; overflow:hidden;}
       .button-content{ width: 48px; float: left; margin-left: 25%; margin-top:-3%;}
  }

  @media screen and (min-width:960px) and (max-width: 1199px){
        
         .image-content{width:100%; height:100px; overflow:hidden; }
        .button-content{ width: 48px; float: left; margin-left: 50%; margin-top:-6.5%;}
    }

@media screen and (min-width:768px) and (max-width: 959px){
        .image-content{width:100%; height:100px; overflow:hidden; }
        .button-content{ width: 48px; float: left; margin-left: 50%; margin-top:-8%;}
    }
/* 媒体查询结束 */

</style>
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" >健康工具</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('tool'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>      
    <?php endif; ?>
   </ul>
</nav>



<!--饮食指南开始-->

<div class="yszn" style="width:90%; height:500px; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center;color: #65a9c6;">基础代谢计算</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;">
    
    <div class=" col-sm-2 col-xs-12" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/basic_metabolism.jpg" class="image-content"> </div>
    <section class=" col-sm-10 col-xs-12" id="tool-content">   
      

<p style="margin-top:3%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

基础代谢率（BMR）是指人体在清醒而又极端安静的状态下，不受肌肉活动、环境温度、食物及精神紧张等影响时的能量代谢率。

基础代谢率对减肥有非常大的影响，每天适量的运动有助于提高身体的基础代谢率，而节食(极端是绝食)会降低人的基础代谢率。通过性别，年龄，身高和体重能粗略计算基础代谢率。

* 本基础代谢计算工具仅适用于一般情况，如需得到个人实际基础代谢情况请使用NICE减重服务。
</p>

     </section>
     <hr style="margin-top: 200px; border:3px  solid #e9e7ef;"/>
    <div class=" col-sm-12 col-xs-12" style="float:left; margin-left:16.5%; width:83.5%; height:25%;">
       请输入您的性别、年龄、身高和体重：</br>
      </br>
      <form action="<?php echo url('basicmetabolismcalculation_record'); ?>" method="post">
        <div class=" ">性别:&nbsp;&nbsp;<input id="sex" name="sex" type="radio" value="男">&nbsp;男&nbsp;&nbsp; <input id="sex" name="sex" type="radio" value="女">&nbsp;女 </div><br/>
        <div class=" ">年龄：<input  id="age" name="age" size="3" type="text" style="width: 50px;">&nbsp;&nbsp;岁</div><br/>
        <div class=" ">身高：<input id="height" name="height" size="6" type="text"  style="width: 50px;">&nbsp;&nbsp; 厘米(cm) </div><br/
        ><div class=""> 体重：<input  id="weight" name="weight" size="6" type="text"  style="width: 50px;">&nbsp;&nbsp;千克(kg) </div><div class=" button-content"><input type="submit" value="确定"></div>
        
        <br/>
        <br/>
         <br/>
      </form>
    </div> 
</div>


<!--饮食指南结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>