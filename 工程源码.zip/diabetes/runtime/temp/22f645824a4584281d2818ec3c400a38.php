<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp\www\diabetes\public/../application/index\view\knowledge\knowledge6.html";i:1555948066;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病知识</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('knowledge'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>      
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病患者需要补硒吗？常吃含硒高的食物有益于健康</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/6.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p style="font-size:16px;">
 </br>
 </br>
    　硒是人体必需的微量元素，也是一种多功能的生命营养素。对于糖尿病患者与微量元素硒的关系，目前存在两种截然相反的观点，即有的赞成补硒，而另一些人则反对补硒。糖尿病需要补硒吗？</br>
 
　　两种观点引发的争论</br>
 
　　第一种看法是缺硒可诱发糖尿病。据加拿大的一项研究表明，人体缺硒是患糖尿病的诱因之一，缺硒会出现一系列糖尿病症状。日本学者也发现微量元素硒具有类似胰岛素的作用，可以调节体内的糖代谢，尤其能降低血糖和尿糖，改善糖尿病症状。另一种看法是补硒可能加重糖尿病。英国学者通过研究发现，一个人血液中的硒含量越高，患糖尿病的风险性就越大。他们认为，糖尿病患者不宜服用硒补充物，否则很可能加重病情。那么糖尿病患者到底能不能补硒呢？问题的关键在于我们应该全面、客观地看问题，不能一概而论。</br>
 
　　糖尿病究竟要不要补硒？</br>
 
　　实验和临床研究证明，硒对糖尿病的防治有益，不仅如此，硒对心血管疾病、消化系统疾病、肿瘤等患者也是有益的，即使是健康的人也不可或缺。关键在于如何知道我们体内是否缺硒。您可以到医院，在医生的帮助下，通过检测手段得到体内血硒水平。如果无法检测，也可以通过膳食调查、临床症状分析等做出相应判断。缺则补，反之则不必额外增加。有一点要明确：缺硒不是糖尿病发病的重要因素，所以我们不要盲目听信商家夸大宣传，不能以为补硒就包治糖尿病。糖尿病的治疗应采取综合策略，通过改变生活方式、控制饮食、适当运动、合理用药、定期监测，使糖尿病得以控制。没有这个前提，缺硒者补硒也无济于事。</br>
 
　　我们需要多少硒？</br>
 
　　对于确定应该补硒的人来说，下一步就是要弄清楚该补多少。在不同地区，正常人群日摄入的阈值是不同的。2002年中国营养学会提出，成人膳食硒推荐摄入量(RNI)为50微克/天，即健康人每天至少需要50微克硒。对于肿瘤、糖尿病、肝病、心脑血管疾病易发家族，及心血管病、糖尿病、肝病、肿瘤患者等特殊人群，专家建议每天应补充100～200微克硒。营养学会制定的硒的可耐受最高摄入量(UL)为400微克/天，即硒的摄入量超过这个剂量，就可能出现对健康不利的影响。</br>
 
　　糖尿病患者补硒有哪些方式？</br>
 
　　到底应该通过饮食补硒，还是通过硒制剂补硒呢？我们认为，硒毕竟是微量营养素，不能过量，否则会事与愿违。如果没有特殊情况，在饮食正常的情况下，一般(也包括糖尿病病人)不会缺硒。如果真的缺硒，首先要科学调理饮食，食物补硒一般就足够了，并且也是最安全的。一般来说，含蛋白质高的食品含硒量较高，动物内脏＞海产品＞鱼类＞蛋类＞肉类＞蔬菜＞水果。举例来说：一天主食中有小麦粉100克(硒6．4微克)，鸡蛋1个(硒12微克)，鲢鱼100克(硒25微克)，鲜蘑菇100克(硒12微克)，即可达到中国营养学会推荐的硒摄入量。大蒜头、猪肾都会增加硒的摄入量，但内脏中胆固醇高，所以不能经常吃，也不宜大量吃。</br>
 
　　综上所述，糖尿病患者常吃含硒高的食物有益于健康且安全。在明确硒缺乏时，可以通过硒制剂补充，但最好在医生或营养师的帮助下服用。一要注意补硒量，二要注意补硒时间，防止过量带来的不利影响。</br>
 </p>
</div>
<div style="margin-left:5%;">
上一篇：<a href="<?php echo url('knowledge5'); ?>">糖尿病患者需要控制喝水吗？患者身体缺水及时补水</a>、</br>
下一篇：<a href="<?php echo url('knowledge7'); ?>">糖尿病饿了吃什么好？糖尿病消除饥饿感的好办法</a> </br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>