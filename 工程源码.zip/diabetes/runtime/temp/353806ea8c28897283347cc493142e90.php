<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"C:\wamp\www\diabetes\public/../application/index\view\tool\countbmi.html";i:1556369347;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>身体质量指数（BMI）</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
<style type="text/css">

/* 媒体查询开始 */
    @media only screen and (max-width:767px){
       
    #tool-content{
     float:left; margin-top:3.5%; height:40%; 
    }
    .image-content{width:80%; height:180px; overflow:hidden; margin-left: 10%; margin-right:10%;}
    .thstyle{font-size: 10px;}
    .button-content{ width: 48px; float: left; margin-left: 30%; margin-top:0%;}
    }


    @media only screen and (min-width:1200px){
         #tool-content{
     float:left; margin-top:3.5%; height:30%;
    }
    .yszn{width:90%; height:500px; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; }
       .image-content{width:100%; height:135px; overflow:hidden;}
       .button-content{ width: 48px; float: left; margin-left: 30%; margin-top:-7.8%;}
  }

  @media screen and (min-width:960px) and (max-width: 1199px){
        
         .image-content{width:100%; height:100px; overflow:hidden; }
         .button-content{ width: 48px; float: left; margin-left: 50%; margin-top:-5%;}
    }

@media screen and (min-width:768px) and (max-width: 959px){
        .image-content{width:100%; height:100px; overflow:hidden; }
        .button-content{ width: 48px; float: left; margin-left: 50%; margin-top:-5%;}
    }
/* 媒体查询结束 */

</style>
</head>
<body style="background-color: #d6ecf0">
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" >健康工具</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse" style="border-top-color:#fff;">
  <ul class="nav navbar-nav">   
    <li><a href="<?php echo url('tool'); ?>">返回主页</a></li>   
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="background-color: #7FD9D6;">
                    <h style="color:#595d5d;; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>" style="color:#595d5d;">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>" style="color:#595d5d;">退出</a></li> 
                </ul>
  </li>      
    <?php endif; ?>
   </ul>
</nav>



<!--饮食指南开始-->
<div class="yszn">
  <h3 style="text-align:center;color: #65a9c6;">身体质量指数（BMI）</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;">
    
    <div class=" col-sm-2 col-xs-12" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/BMI.jpg"  class="image-content"> </div>
    <div class=" col-sm-10 col-xs-12" id="tool-content">   
      

<p style="margin-top:3%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BMI[Body Mass Index] 即BMI指数，也叫身体质量指数，是衡量是否肥胖和标准体重的重要指标。

适用范围：18至65岁的人士。儿童、发育中的青少年、孕妇、乳母、老人及身型健硕的运动员除外。

世界卫生组织认为BMI指数保持在22左右是比较理想的。</p>

     </div>
     <hr style="margin-top: 200px; border:3px  solid #e9e7ef;"/>
    <div class=" col-sm-12 col-xs-12" style="float:left; margin-left:16.5%; width:83.5%; height:25%;">
       请输入您的身高和体重：</br>
       </br>
       <form action="<?php echo url('countbmi_record'); ?>" method="post">
       <div>身高：
        <input name="height" size="6" type="text">&nbsp;&nbsp;厘米(cm)  
       </div><br/>
        <div >体重：
          <input name="weight" size="6" type="text">&nbsp;&nbsp;千克(kg) 
        </div><br/><br/>
          <div class="button-content" >
            <input type="submit" value="确定" />
          </div>
       </form>
    </div> 
    <div >
       <table class="table table-bordered" >
  <caption style="text-align:center;color: black;">成年人身体质量指数</caption>
  <thead >
    <tr>
      <th class="thstyle">轻体重BMI</th>
      <th class="thstyle">健康体重BMI</th>
      <th class="thstyle">超重BMI</th>
      <th class="thstyle">肥胖BMI</th>
    </tr>
  </thead>
  <tbody >
    <tr>
      <td class="thstyle">BMI<18.5</td>
      <td class="thstyle">18.5≤BMI<24</td>
      <td class="thstyle">24≤BMI<28</td>
      <td class="thstyle">28≤BMI</td>
    </tr>
  </tbody>
</table>
    </div>
</div>


<!--饮食指南结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>