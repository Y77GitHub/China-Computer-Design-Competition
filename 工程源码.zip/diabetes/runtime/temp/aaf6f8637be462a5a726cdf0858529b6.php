<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\wamp\www\diabetes\public/../application/index\view\information\information12.html";i:1551790151;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病的症状突然全部消失未必全是好事</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" href="#">糖尿病预防</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('information'); ?>">糖尿病知识</a></li>
    
  </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病的症状突然全部消失未必全是好事</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-3" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/1.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p >
 </br>
 </br>
个别糖尿病患者说，为自己的症状全部消失而感到非常高兴。其实，糖尿病症状的全部消失未必全是好事。比如患者若患上脑垂体瘤，就可能出现糖尿病症状全部消失的情况。</br>
 
　　人体的脑垂体前叶分泌促肾上腺皮质激素、促甲状腺激素和生长激素，这些激素作用于肾上腺和甲状腺，使人体内肾上腺皮质激素和甲状腺激素分泌增加，直接促使血糖增高。而生长激素则通过抑制葡萄糖酶而产生抗胰岛素作用，也使血糖增高。当脑垂体发生肿瘤时，有关功能下降，肾上腺皮质激素、甲状腺激素和生长激素分泌减少，血糖就会随之而降，此时，糖尿病患者的症状就会消失。因此，当糖尿病患者在没有确切的原因的情况下，症状突然全部消失，就应该到医院进行专科检查，以明确原因。</br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>