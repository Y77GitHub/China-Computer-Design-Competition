<?php
namespace app\index\controller;

use think\View;
use think\Db;   //导入系统数据库类
use think\Controller;  //引入系统控制器类    初始化方法要用
use think\Cookie;

class Tool extends Controller
{

    public function myinfo(){
        return $this->redirect('Information/myinfo');
    }

    //退出登录
    public function logout(){
        if(!cookie(null,'username')){
            $this->success('退出成功','Index/index'); 
        }else{
            $this->error('退出失败，请重试');
        }      
    }

    public function basicmetabolismcalculation_record(){
        $redata=input('post.');
        $data['height']=trim($redata['height']);
        $data['weight']=trim($redata['weight']);
        $data['age']=trim($redata['age']);
        $name=trim(cookie('username'));
        if($data['height']=="" || $data['weight']=="" || $data['age']==""){
            return $this->error('请填入每个数据');
        }else if(!is_numeric($data['age'])){
            return $this->error('请填入年龄的正确数据');
        }else if(!is_numeric($data['weight'])){
            return $this->error('请填入体重的正确数据');
        }else if(!is_numeric($data['height'])){
            return $this->error('请填入身高的正确数据');
        }else{
            if($redata['sex']=="女"){
                $record = round(661+9.6*$data['weight']+1.72*$data['height']-4.7*$data['age']);
            }else{
                $record=round(67+13.73*$data['weight']+5*$data['height']-6.9*$data['age']);
            }
            echo "<script> alert('您的基础代谢率为  '+$record+'  大卡'); history.go(-1); </script>";
        }  
    }

    public function countbmi_record(){
        $redata=input('post.');
        $data['weight']=trim($redata['weight']);
        $data['height']=trim($redata['height']);
        if($data['weight']==0 || $data['height']==0){
            echo "<script> alert('请填入身高或体重的正确数据'); history.go(-1); </script>";
        }
        $record = round($data['weight']/($data['height']*$data['height']*0.01*0.01));
        if($record<18.5){
            echo "<script> alert('你的BMI: '+$record+'  (偏瘦)'); history.go(-1); </script>";
        }else if($record<=24){
            echo "<script> alert('你的BMI: '+$record+'  (正常)'); history.go(-1); </script>";
        }else if($record<=28){
            echo "<script> alert('你的BMI: '+$record+' (过重)'); history.go(-1); </script>";
        }else if($record<=32){
            echo "<script> alert('你的BMI: '+$record+'  (肥胖)'); history.go(-1); </script>";
        }else{
            echo "<script> alert('你的BMI: '+$record+'  (非常肥胖)'); history.go(-1); </script>";
        }
    }

    public function healthyweightscope_record(){
        $redata=input('post.');
        $data['height']=trim($redata['height']);
        if($data['height']==0){
            echo "<script> alert('请填入身高的数据'); history.go(-1); </script>";
        }
        $weight1=round($data['height']*$data['height']*0.01*0.01*18.5);
        $weight2=round($data['height']*$data['height']*0.01*0.01*24);
        echo "<script> alert('你的健康体重范围: '+$weight1+'kg'+'~'+$weight2+'kg'); history.go(-1); </script>";
    }

    public function bloodsugarrecord_record(){
        $data=input('post.');        
        $redata['time']=trim($data['time']);
        $redata['breakfast_before']=trim($data['breakfast_before']);
        $redata['breakfast_after']=trim($data['breakfast_after']);
        $redata['lunch_before']=trim($data['lunch_before']);
        $redata['lunch_after']=trim($data['lunch_after']);
        $redata['dinner_before']=trim($data['dinner_before']);
        $redata['dinner_after']=trim($data['dinner_after']);
        $redata['extra_meal_before']=trim($data['extra_meal_before']);
        $redata['extra_meal_after']=trim($data['extra_meal_after']);
        $redata['sleep']=trim($data['sleep']);
        $name=cookie('username');
        if($name==null){
            return $this->error('请先登录','Index/index');
        }
        $id=Db::table('user')->where('username',$name)->value('id');
        if($redata['time']==""){
            return $this->error('日期不能为空，请重新输入');
        }
        if(!Db::table('record')->where('uid',$id)->find()){
            $re_id=['uid'=>$id];
            Db::table('record')->insert($re_id);
            Db::table('record')->where(['uid'=>$id])->update(['time'=>$redata['time']]);
            if($redata['breakfast_before']!=null){
                if(!is_numeric($redata['breakfast_before'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['breakfast_before'=>$redata['breakfast_before']]);
            }
            if($redata['breakfast_after']!=null){
                if(!is_numeric($redata['breakfast_after'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['breakfast_after'=>$redata['breakfast_after']]);
            }
            if($redata['lunch_before']!=null){
                if(!is_numeric($redata['lunch_before'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['lunch_before'=>$redata['lunch_before']]);
            }
            if($redata['lunch_after']!=null){
                if(!is_numeric($redata['lunch_after'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['lunch_after'=>$redata['lunch_after']]);
            }
            if($redata['dinner_before']!=null){
                if(!is_numeric($redata['dinner_before'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['dinner_before'=>$redata['dinner_before']]);
            }
            if($redata['dinner_after']!=null){
                if(!is_numeric($redata['dinner_after'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['dinner_after'=>$redata['dinner_after']]);
            }
            if($redata['extra_meal_before']!=null){
                if(!is_numeric($redata['extra_meal_before'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['extra_meal_before'=>$redata['extra_meal_before']]);
            }
            if($redata['extra_meal_after']!=null){
                if(!is_numeric($redata['extra_meal_after'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['extra_meal_after'=>$redata['extra_meal_after']]);
            }
            if($redata['sleep']!=null){
                if(!is_numeric($redata['sleep'])){
                    return $this->error('血糖含量请填入整数或小数');
                }
                Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['sleep'=>$redata['sleep']]);
            }
            return $this->success('记录成功');
        }else{
            $retime=Db::table('record')->where('uid',$id)->column('time');
            for($i=0;$i<count($retime);$i++){
                if($retime[$i]==$redata['time']){
                    if($redata['breakfast_before']!=null){
                        if(!is_numeric($redata['breakfast_before'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['breakfast_before'=>$redata['breakfast_before']]);
                    } 
                    if($redata['breakfast_after']!=null){
                        if(!is_numeric($redata['breakfast_after'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['breakfast_after'=>$redata['breakfast_after']]);
                    }
                    if($redata['lunch_before']!=null){
                        if(!is_numeric($redata['lunch_before'])){
                         return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['lunch_before'=>$redata['lunch_before']]);
                    }
                    if($redata['lunch_after']!=null){
                        if(!is_numeric($redata['lunch_after'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['lunch_after'=>$redata['lunch_after']]);
                    }
                    if($redata['dinner_before']!=null){
                        if(!is_numeric($redata['dinner_before'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['dinner_before'=>$redata['dinner_before']]);
                    }
                    if($redata['dinner_after']!=null){
                        if(!is_numeric($redata['dinner_after'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['dinner_after'=>$redata['dinner_after']]);
                    }
                    if($redata['extra_meal_before']!=null){
                        if(!is_numeric($redata['extra_meal_before'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['extra_meal_before'=>$redata['extra_meal_before']]);
                    }
                    if($redata['extra_meal_after']!=null){
                        if(!is_numeric($redata['extra_meal_after'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['extra_meal_after'=>$redata['extra_meal_after']]);
                    }
                    if($redata['sleep']!=null){
                        if(!is_numeric($redata['sleep'])){
                            return $this->error('血糖含量请填入整数或小数');
                        }
                        Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['sleep'=>$redata['sleep']]);
                    }
                    return $this->success('记录成功');
                }
            }
            if(Db::table('record')->insert(['uid'=>$id,'time'=>$redata['time']])){
                if($redata['breakfast_before']!=null){
                    if(!is_numeric($redata['breakfast_before'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['breakfast_before'=>$redata['breakfast_before']]);
                }
                if($redata['breakfast_after']!=null){
                    if(!is_numeric($redata['breakfast_after'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['breakfast_after'=>$redata['breakfast_after']]);
                }
                if($redata['lunch_before']!=null){
                    if(!is_numeric($redata['lunch_before'])){
                         return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['lunch_before'=>$redata['lunch_before']]);
                }
                if($redata['lunch_after']!=null){
                    if(!is_numeric($redata['lunch_after'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['lunch_after'=>$redata['lunch_after']]);
                }
                if($redata['dinner_before']!=null){
                    if(!is_numeric($redata['dinner_before'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['dinner_before'=>$redata['dinner_before']]);
                }
                if($redata['dinner_after']!=null){
                    if(!is_numeric($redata['dinner_after'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['dinner_after'=>$redata['dinner_after']]);
                }
                if($redata['extra_meal_before']!=null){
                    if(!is_numeric($redata['extra_meal_before'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['extra_meal_before'=>$redata['extra_meal_before']]);
                }
                if($redata['extra_meal_after']!=null){
                    if(!is_numeric($redata['extra_meal_after'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['extra_meal_after'=>$redata['extra_meal_after']]);
                }
                if($redata['sleep']!=null){
                    if(!is_numeric($redata['sleep'])){
                        return $this->error('血糖含量请填入整数或小数');
                    }
                    Db::table('record')->where(['uid'=>$id,'time'=>$redata['time']])->update(['sleep'=>$redata['sleep']]);
                }
                return $this->success('记录成功');
            }else{
                return $this->error('记录失败，请重新填入');
            }                            
        }
    }
    
	public function tool()
    {
        return $this->redirect('Index/index');
    }

	public function basicmetabolismcalculation()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function bloodsugarrecord()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function countbmi()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function healthyweightscope()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }
}
