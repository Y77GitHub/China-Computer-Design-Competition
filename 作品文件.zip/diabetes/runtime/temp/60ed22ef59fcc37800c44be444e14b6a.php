<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information6.html";i:1556207389;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body style="background-color: #d6ecf0">
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>    
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病会增加肝切除术后急性肾衰及败血症发生风险</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
 <p style="font-size:16px;">
 </br>
  
　&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;糖尿病（DM）是一种常见的影响全球的慢性疾病。在心血管及其他类型的手术中，dm被认为会导致围手术期并发症和死亡率升高。有研究表明：dm会导致因直肠癌肝转移患者肝切除术后的死亡率升高，同时也会导致肝细胞癌（hcc）患者的肝切除术后的总体并发症发生率升高。然而，poon等人的研究却发现：dm并未对肝切除术后的死亡率和并发症发生率产生影响。因此，关于dm是否会增加肝切除术围手术期并发症发生率及死亡率这一问题，目前尚存争议。</br>
 
　　之前的相关研究都存在纳入的病人数较少并且都是来自单中心的研究等问题。目前尚未有对该类问题进行基于人群的队列研究。因此，针对dm对hcc患者肝切除术后死亡率及并发症发生率的影响这一问题，来自台湾多家医院的外科医生组成的研究团队进行了回顾性的病例对照研究。研究结果最近发表于annalsofsurgicaloncology杂志。研究发现dm会显著增加hcc患者肝切除术后败血症及急性肾衰竭的发生风险。</br>
 
　　该回顾性研究纳入了2962名在2000-2010年间进行肝切除术的患有dm的hcc患者。同时根据年龄、性别、伴发疾病以及入院日期进行匹配，纳入了2962名在同一时间段接受肝切除术的非dm的hcc患者。</br>
</div>
</p>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>