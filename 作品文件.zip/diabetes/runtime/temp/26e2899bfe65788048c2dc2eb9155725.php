<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp\www\diabetes\public/../application/index\view\knowledge\knowledge1.html";i:1556358625;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" >糖尿病知识</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse" style="border-top-color:#fff;">
  <ul class="nav navbar-nav">   
    <li><a href="<?php echo url('knowledge'); ?>">返回主页</a></li>   
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="background-color: #7FD9D6;">
                    <h style="color:#595d5d;; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>" style="color:#595d5d;">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>" style="color:#595d5d;">退出</a></li> 
                </ul>
  </li>      
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">控制饮食战胜糖尿病 甜蜜事业之餐桌上的革命</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/1.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p style="font-size:16px;">
 </br>
</br>
    “餐桌上的革命”是人类随着社会发展的变化对饮食生活的改变，这是我对餐桌上的革命的粗浅理解。</br>
 
　　糖尿病人要想控制好血糖，健康长寿的活着，不论是吃药打针还是裸奔，都必须彻底改变过去几千年的饮食习惯，定时定量，营养均衡，少吃多餐，会吃会喝，这就是餐桌上的革命 。</br>
 
　　忆往昔，记忆犹新常反思。患病前大吃大喝无法避免，大鱼大肉几乎不断，甜食糖类酷爱如命，个小肚大饭量最大。记得那年去山西天镇，三张大糖饼下肚，20多人就数我最能吃！去大同办案，招待所管吃饱子，我们一伙“吃货”吃了很多，被服务员笑话，再不想给我们端饭。当然，忍饥挨饿也是常有的事。以前，不吃早饭是养成的习惯，到了中午接到报案，谁能顾得吃饭，往往到了下午三四点才能填饱肚子，到了晚上谁还能吃得下饭。农村办案，饭是不会按时按点，急水下浆，毫无准备，一锅鸡蛋，一堆豆腐皮就是一顿饭。记得那年去一个村办案，村里给炒葵花籽也顶一顿饭。饥饱劳伤是刑侦工作的饮食特点，那个年代，那一伙人，就这么拼死拼活的无私奉献。</br>
 
　　有资料显示，刑侦干警的平均寿命最短，英年早逝屡见不鲜。六月十七日是我肠手术二十周年纪念日。医生预言能活二十年。癌与我亲密接触，死神和我擦肩而过，。经历过大风大浪，何惧毛毛细雨？经历过惊心动魄的癌，何惧可防可控的糖？当发现糖尿病的时候，因为我有抗癌的经历，所以没有象有的人惊慌失措，没有痛不欲生，更没有轻身自杀，更没有麻木不仁，熟视无睹。我镇定自若，泰然处之，面对现实，积极应对。糖尿病和癌比起来，可谓小巫见大巫，癌说是能防能治，癌不等于死亡，但任何人在癌面前都会低头！没有一人不害怕，糖尿病不可怕，可怕的是并发症，咱还没有并发症，只要能控制咱就控制。所以，自从发现血糖高的2001.2.1那一天起，烟戒了，酒戒了，饭少了，肉少了，糖不吃了，牛奶、鸡蛋天天吃上了，蔬菜一顿饭都离不了了，一句话，就为了控制、控制、再控制。13年如一日，一餐都没放肆过，一顿没敢嘴贪过，就这么过来了，餐桌上的革命不过如此而已。</br>
 
　　看今朝，精彩生活每一天。现在的我，血糖正常，血脂正常，血压正常，糖化正常，体重正常，身体健康，浑身有劲，精力充沛，生活充实。早晚坚持两次锻炼，做到风雨无阻，坚持不懈；每天三正三加餐吃饭，坚持三年之久，早已形成习惯；加餐吃红枣、各种水果坚果、木糖醇糕点，照常享受美餐；肉、蛋、奶、豆制品、蔬菜每天的餐桌上不能缺，不嫌好赖，多多以善；上午经营无糖店，还有照相、复印、传真、扫描，有时忙的应接不暇，使我的店里人气十足，弥补了店处偏僻，远离闹市之不足；中午看店不休息，下午喂鸡干活还种地，享受田园生活乐趣；看店的时候，每天有点时间就上网，甜蜜家园、糖护士、5199、糖帮帮是忠实会员，水平不高还想写些帖子，介绍自己的抗糖经验；QQ糖友多到全国各地，有问必答，有的时候同时与二三位糖友聊病，常常聊到十一二点；上门咨询交流的更是络绎不绝，用自学的知识宣传指导糖友成为最大的乐趣。这就是我每天老有所为、老有所乐、忙忙碌碌生活的真实写照。</br>
 
　　<h3>我的餐桌革命是如何进行的呢？</h3></br>
 
　　早晨起床，喝一杯净水机水，吃20多克红枣，锻炼回来1小时最多1.5小时吃早正餐，半斤鲜牛奶或店里的富铬奶粉一袋，我养的鸡下的柴鸡蛋一颗，花卷、馒头、烙饼、饱子或店里的无糖食品100多克，有豆制品或者花生米就吃，有蔬菜更好，没有就不吃。</br>
 
　　上午一般11点加餐吃水果，苹果、梨、桃、香蕉、橘子、葡萄等，有啥吃啥，什么都吃，苹果吃200---250克，葡萄、香蕉之类生糖指数高的不超过200克。中午12点吃正餐，主食以米饭、馒头、饱子、莜面什么都吃，有粗不吃细，控制在熟重130--150克以内，豆制品差不多每餐都有，什么肉都吃，不吃肥肉和动物内脏，最多不超过2俩，蔬菜随便吃，一般能吃饱。</br>
 
　　下午5点，我都去旧房喂鸡狗，房里放着店里的无糖饼干、沙琪玛、曲奇饼、蛋糕，一般吃30克左右，有时还要吃我院内树上结的大杏扁10几颗。晚上6点吃正餐，主食和中午差不多，一般不吃肉，豆制品、蔬菜顿顿有。</br>
 
　　晚上，一般不加餐，让胰岛得以充分休息。有时磕些葵花籽，吃二颗核桃，睡前服鱼油、卵磷脂、维生素E、蜂胶。</br>
 
　　以上的三正餐三加餐的饮食习惯是三年前学习美国陈老师的食物促泌法形成的，有较严格的时间、食物品种和量。它与少吃多餐、分餐有相同之处，也有本质的区别，不能说不是一场餐桌上的革命。</br>
 
　　为什么我能13年成功裸奔，战胜糖尿病。我的体会是：</br>
 
　　<h3>一、主副颠倒，副食为主。</h3></br>
 
　　主食顾名思义是主要食物，一般指“饭”，副食是指“菜”。 中华民族几千年的饮食习惯是以粮食为主，以菜为辅。糖尿病患者一天的主食原则上不能超过5两，对平时一餐能吃5两甚至更多的人，尤其是不喜欢吃菜的人必须转变思想，改变饮食习惯，主副颠倒，把副食作为主要食物。 肉、蛋、奶、豆制品限量吃，蔬菜填饱肚子。否则就会饥饿，营养就会缺乏，身体素质就会下降。</br>
 
　　糖尿病控制靠五驾马车，饮食是驾辕之马,饮食中主食最为关键。无论何种类型的糖尿病人,采用何种治疗方法，都要控制主食。不会控制主食不论你吃药打针都不会把血糖控制好，更别说是裸奔的人，哪怕是多吃一口“饭”，血糖就会飙升。当然，如果主食摄入过低，机体分解蛋白质、脂肪，就会进一步造成三大代谢紊乱，甚至产生酮症酸中毒。</br>
 
　　<h3>二、结构合理，营养均衡。</h3></br>
 
　　正常人吃什么，吃多少都无所谓，糖人就不一样了。每餐的饭菜一定要多样化，不能过于简单，荤素搭配，三大营养均衡摄取。人们往往不重视这一问题，一餐中，如果仅吃主食，不吃副食血糖就会高，餐后三四小时可能会出现低血糖或者低血糖反应，如果控制好主食加吃肉蛋奶、豆制品、蔬菜，血糖就能平稳，甚至会降低，还不出现低血糖。 蛋白质是人体细胞的食粮，不能缺，缺了细胞就会饥饿，就不活跃。 脂肪吃的多了不好，不吃也不行，更不能缺少不饱和脂肪酸。  现代的人不缺糖，一人一天的碳水摄入一般三至五两就能满足需求量。碳水、蛋白质、脂肪三大营养必须按一定比例摄入才是会吃。</br>
 
　<h3>　三、粗细搭配，精粮少吃。</h3></br>
 
　　精米精面丢失百分之九十的铬，人体缺乏铬就会发生肥胖、高血压、高血脂、高血糖，糖人一定要少吃精米精面。粗粮富含微量营养元素，升糖指数低，升糖速度慢，最适合糖人食用。肠胃不好的人天天吃粗粮会引起消化不良，本来生活条件好了，餐桌上全是白米饭和白面面食，只要控制好量吃也无妨。因此，粗细搭配是糖人最好的选择，做到有粗不吃细，仅细也不怕，关键控制量也是会吃。</br>
 
　<h3>　四、少吃多餐，加餐促泌。</h3></br>
 
　　2型糖人多数是胰岛素抵抗加分泌延迟，除吃增敏降糖药外，通过饮食疗法也可以有效地把血糖控制平稳，少吃多餐能把血糖削峰填谷，少吃血糖波动就不会太大，多餐血糖就会形成多个小的血糖峰值。能有效地消除胰岛素抵抗，保护胰岛功能。定时定量加餐可以提前促进胰岛素分泌，解决胰岛素分泌延迟，降低餐后血糖，能起到药物促泌的作用。</br>
 
　　<h3>五、宜慢勿快，顺序调整。</h3></br>
 
　　吃饭的速度影响升糖的快慢，狼吞虎咽血糖就会迅速上升，细嚼慢咽血糖就会缓慢上升，糖人切记吃饭不要太快。吃饭时，先吃什么后吃什么食物的顺序也很重要，先吃主食，血糖就上升快，先吃肉、蛋、奶、豆制品、蔬菜，后吃主食或者边吃菜边吃饭血糖就会平稳。</br>
 
　<h3>　六、学会喝水，水能控糖。</h3></br>
 
　　水是生命之源，糖人必须学会喝水。空腹喝水能补充身体水分，稀释血液。饭前半小时喝水，能缓饥饿感，减少饮食量。饭中饭后不喝水能保护肠胃，防止血糖升高太快。一天中不能缺水，缺水，体内的毒素就不能排除，血液粘稠度就会增高，血糖就得不到有效控制。</br>
 
　　民以食为天。糖人不吃饭不行，糖尿病人必须会吃会动，吃动两平衡。让我们拿起餐桌上的革命这一抗糖武器，勇敢的战胜糖魔，过上幸福甜蜜的精彩生活！</br>
 
　　“不活到九十九，坚决不能走”，让这句时髦的口号成为我们每个糖友的中国梦！</br>
 </p>
</div>
<div style=" margin-left:5%;">
上一篇:无</br>
下一篇:<a href="<?php echo url('knowledge2'); ?>">糖尿病能吃燕麦吗？燕麦平缓餐后血糖上升</a></br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>