<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp\www\diabetes\public/../application/index\view\knowledge\knowledge3.html";i:1551788165;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>推荐五种降血糖食物帮你控制糖尿病病情</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" href="#">糖尿病预防</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('knowledge'); ?>">糖尿病知识</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <li> 
      <!-- 按钮触发模态框 -->
      <button class="btn btn-primary btn-lg " data-toggle="modal" data-target="#myModal" > 注册 </button>
      </span></li>
    <li>
      <button class="btn btn-primary btn-lg " data-toggle="modal" data-target="#myModal1" > 登录 </button>
    </li>
  </ul>
  <!-- 模态框（Modal开始） -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" 
            aria-hidden="true">× </button>
          <h4 class="modal-title" id="myModalLabel"> 您好，请注册！ </h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" action="<?php echo url('register'); ?>" method="post">
            <div class="form-group">
              <label for="name" class="col-sm-3 control-label">用户名</label>
              <div class="col-sm-9">
                <input type="text" id="name" name="name" class="form-control well" placeholder="请输入您喜欢的用户名"/>
              </div>
            </div>
            <div class="form-group">
              <label for="pass" class="col-sm-3 control-label">密码</label>
              <div class="col-sm-9">
                <input type="password" id="pass" name="pass" class="form-control well" placeholder="请输入密码（长度在6-12之间）"/>
              </div>
            </div>
            <div class="form-group">
              <label for="pass" class="col-sm-3 control-label">确认密码</label>
              <div class="col-sm-9">
                <input type="password" id="pass" name="pass" class="form-control well" placeholder="请再输入密码"/>
              </div>
            </div>
          
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary"> 注册 </button>
          <button type="reset" class="btn btn-default" 
            data-dismiss="modal">清除 </button>
            </form>
        </div>
      </div>
    </div>
  </div>
  
  <!-- 模态框（Modal） -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" 
            aria-hidden="true">×
        </button>
        <h4 class="modal-title" id="myModalLabel">
          您好，请登录！
        </h4>
      </div>
      <div class="modal-body">
        
                <form class="form-horizontal" role="form" action="<?php echo url('login'); ?>" method="post">
                            <div class="form-group">
                                <label for="name" class="col-sm-3 control-label">用户名</label>
                                <div class="col-sm-9">
                                    <input type="text" id="name" name="name" class="form-control well" placeholder="请输入您的用户名"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="pass" class="col-sm-3 control-label">密码</label>
                                <div class="col-sm-9">
                                    <input type="password" id="pass" name="pass" class="form-control well" placeholder="请输入密码"/>
                                </div>
                            </div>
                            <div class="form-group">
                              <label for="captcha" class="col-sm-3 control-label">验证码</label>
                                <div class="col-sm-9">
                                    <input type="text" placeholder="验证码" name="captcha" class="form-control well"/>
                                    <img src="<?php echo captcha_src(); ?>" class="verify" onclick="javascript:this.src='<?php echo captcha_src(); ?>?rand='+Math.random()" >
                                </div>
                            </div>
                            
                        
      <div class="modal-footer">
        
        <button type="submit" class="btn btn-primary">
          登录
        </button>
                <button type="button" class="btn btn-default" 
            data-dismiss="modal">取消
        </button>
        </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
    </div>
    
    </div>
  <!-- 模态框（Modal）结束 --> 
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">推荐五种降血糖食物帮你控制糖尿病病情</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-3" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/3.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p >
 </br>
 </br>
    　饮食搭配不合理可能诱发甚至加重糖尿病病情，但也有一些食物对控制糖尿病病情降血糖有很多好处。</br>
 
　　初榨橄榄油：《内科学文献》杂志刊登一项研究显示，橄榄油富含单不饱和脂肪，有助于降低血糖和血压。还含有抗氧化剂橄榄油刺激醛，能降低C反应蛋白，减少炎症发生，进而缓解糖尿病病情。</br>
 
　　野生三文鱼：美国加州大学研究人员发现，野生三文鱼中富含的欧米伽-3脂肪酸，可改善胰岛素敏感性和减少炎症。75%的糖尿病死亡病例，其实都是因为心脏病或中风导致的。《新英格兰医学杂志》刊登一项为期17年的研究发现，提高血液中欧米伽-3脂肪酸水平可以降低心脏病猝死危险。</br>
 
　　豆类：豆类富含纤维素和镁，前者有助于提高血糖耐受力，而对于后者，哈佛大学一项涉及8.5万参试者的研究发现，摄入镁较多的人，其糖尿病患病风险降低30%。</br>
 
　　洋葱：它是微量元素铬的重要食物来源。研究发现，铬有助于人体更有效地利用胰岛素，保持血糖稳定。《生物化学》杂志刊登一项近期研究发现，铬是胰岛素增强剂。1杯生洋葱或半杯熟洋葱含24微克铬(健康指南推荐日摄入量为25-35微克)。</br>
 
　　坚果：坚果中的单不饱和脂肪酸有助于逆转胰岛素抵抗。每天吃坚果还可使心脏病患病风险降低35%。《代谢》杂志载文称，杏仁是坚果首选，因其富含蛋白质和抗氧化剂，常吃可降低升糖指数。另有研究发现，每周吃5次花生酱的妇女，罹患2型糖尿病和心血管疾病危险降低20%。</br>
 </p>
</div>
<div style="margin-left:5%;">
上一篇：<a href="糖尿病知识---2.html">糖尿病能吃燕麦吗？燕麦平缓餐后血糖上升</a>、</br>
下一篇：<a href="糖尿病知识---4.html">吃甜食多就会得糖尿病吗？糖尿病患者还能吃甜食吗？</a> </br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>