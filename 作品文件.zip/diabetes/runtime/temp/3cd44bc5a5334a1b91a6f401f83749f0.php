<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp\www\diabetes\public/../application/index\view\knowledge\knowledge7.html";i:1555948086;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病知识</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('knowledge'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>     
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病饿了吃什么好？糖尿病消除饥饿感的好办法</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/7.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p style="font-size:16px;">
 </br>
 </br>
    　糖尿病患者总是爱饿，好想大吃一顿，可是害怕病情加重，这确实是个棘手的问题。怎么办才好呢？饿了总是需要补充能量的，不然自己也不舒服。下面介绍几种方法，希望可帮助糖尿病患者应对饥饿感。</br>
 
　　糖尿病患者要了解饥饿感是糖尿病的一种症状，在患者病情控制不好的情况下，饥饿感明显(与低血糖时出现的饥饿感不是一回事，可通过监测血糖区分开)，经治疗，这种饥饿感会随之减轻或消失，所以糖尿病患者一定要树立治病信心。</br>
 
　　糖尿病患者控制饮食，应循序渐进，可每周减少主食100~200克，一般1个月左右应限制到每日300克左右。调整饮食结构对减轻饥饿感也有一定帮助，宜多吃低热量食物，如黄瓜、大白菜、豆芽、菠菜、冬瓜、南瓜、韭菜、青椒、莴笋、茄子、菜花等；多选用粗杂粮代替细粮，如红豆粥、馒头(三合面、玉米面制作而成)等。高纤维食物(如麦麸、玉米皮等)可使胃排空延缓，增强耐饥力，宜多吃。此外，苦荞麦中含有人体必需的锌、镁、铬、硒等多种微量元素，其中铬是参与胰岛素代谢的，所以对糖尿病初期饥饿感明显的人，可适当多吃点。</br>
 
　　糖尿病患者每次进餐前先吃一碗蔬菜(含碳水化合物4%以下的蔬菜任选一种，少用油)，以增加饱腹感，然后再进正餐。两餐之间饥饿时，可吃些黄瓜、西红柿等或采用加餐的方法，当然加餐的量是从正餐中减去的，而不是额外增加的量，或把菜做得淡些，以降低食欲。</br>
 </p>
</div>
<div style="margin-left:5%;">
上一篇：<a href="<?php echo url('knowledge6'); ?>">糖尿病患者需要补硒吗？常吃含硒高的食物有益于健康</a></br>
下一篇：<a href="<?php echo url('knowledge8'); ?>">糖尿病饮食治疗的一般原则是什么？控制总热量的摄入</a></br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>