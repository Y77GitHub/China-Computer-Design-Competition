<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information8.html";i:1556207417;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body style="background-color: #d6ecf0">
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>     
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">1型糖尿病早期症状有哪些？夏季糖尿病人需要注意什么？</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
 <p style="font-size:16px;">
 </br>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1型糖尿病是由于免疫系统发育不良或免疫应激引发的糖尿病。又名胰岛素依赖型糖尿病（IDDM）或青少年糖尿病。随着1型糖尿病越来越高的发病率，使越来越多的人开始关注1型糖尿病。那么，1型糖尿病发病的早期症状有哪些？ </br></br>
 
　　1、身体倦怠，整天提不起精神，腰膝酸软，两腿乏力，什么事都懒得做，连走路、上楼梯都感到疲 惫不堪，饭后困怠思睡。 </br>
 
　　2、因皮肤抵抗力减弱，经常会发痒，女性患者有时会痒及阴部，如果皮肤受伤，容易感染腐烂，还 会长疥疮。 </br>
 
　　3、视力明显减退，看书、看报眼睛容易疲劳，并经常发生视网膜的病变。 </br>
 
　　4、患者因体内糖分随小便排出，所以经常感到饥饿而出现食欲亢进，而且有喜好吃甜食的倾向。 </br>
 
　　5、持续性感到喉咙干渴，饮水量大幅度增加，小便次数一天十多次。 </br>
 
　　6、女性患者出现月经不规则或闭经等月经失调。 </br>
 
　　7、手腿出现顽固性的麻痹和阵痛，有时会有剧烈的疼痛，也有人夜间小腿常常抽筋。 </br>
　
</div>
</p>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>