<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\wamp\www\diabetes\public/../application/index\view\knowledge\knowledge2.html";i:1556009010;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病知识</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('knowledge'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li> 
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病能吃燕麦吗？燕麦平缓餐后血糖上升</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/2.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p style="font-size:16px;">
 </br>
 </br>
    燕麦中含有水溶性膳食纤维</br>
　　
　　燕麦中的水溶性膳食纤维具有平缓饭后血糖上升的效果，有助于糖尿病患者控制血糖。每天40克为宜。</br>
　　
　　燕麦营养档案</br>
　　
　　【性味归经】 性温、味甘、归脾、胃经。</br>
　　
　　【营养功效】 燕麦含有不饱和脂肪酸及可溶性纤维和皂甙素等，可以降低血液中胆固醇与甘油三酯的含量，既能调脂减肥，又可帮助降低血糖，预防动脉粥样硬化，高血压、冠心病，还有润肠通便的作用。燕麦中富含维生素e，可以抗氧化、美肌肤、具有很好的美容功效。燕麦还具有补益脾胃、滑肠、止虚汗和止血等功效。</br>
　　
　　燕麦烹调宜忌</br>
　　
　　避免长时间高温煮燕麦片，以防止维生素被破坏。</br>
　　
　　燕麦食用宜忌</br>
　　
　　燕麦营养虽然丰富，但一次不宜吃得太多，否则会造成胃痉挛或者腹部胀气。</br>
 </p>
</div>
<div style="margin-left:5%;">
上一篇：<a href="<?php echo url('knowledge1'); ?>">控制饮食战胜糖尿病 甜蜜事业之餐桌上的革命</a>、</br>
下一篇：<a href="<?php echo url('knowledge3'); ?>">推荐五种降血糖食物帮你控制糖尿病病情</a> </br>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>