<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information9.html";i:1556207420;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body style="background-color: #d6ecf0">
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>     
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病的早期症状有哪些？警惕糖尿病的18种早期症状</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/information9.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
 <p style="font-size:16px;">
 </br>
  糖尿病分1型、2型、妊娠糖尿病及特殊型糖尿病，无论患上哪种糖尿病，治疗过程中都离不开血糖的监测与控制，将血糖控制在理想的范围内，是延缓糖尿病进展及并发症发生的关键。</br>
 
　　糖尿病患者在监测血糖过程中，要避免不把血糖监测放在心上，测也行不测也行。有些患者血糖稍高时毫无感觉，认为测不测无所谓，这种轻视稍高血糖的行为，容易促发慢性并发症，直到有了症状以后才测血糖，往往为时已晚；有的患者怕麻烦认为少测几次血糖无所谓，几个月才测一次，这是远远不够的，因为血糖可以受饮食、活动、药物、情绪等影响而发生波动，如果让血糖长期处在无序波动状态，采取控糖的措施又十分盲目，那发生高血糖或低血糖的后果是不堪设想的；尤其对于用胰岛素治疗的患者，为了观察剂量是否合适及避免低血糖，测的次数应要更多。总之，糖尿病患者要养成自我血糖监测的习惯，这对于防治糖尿病是有百利而无一害的。</br>

</div>
</p>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>