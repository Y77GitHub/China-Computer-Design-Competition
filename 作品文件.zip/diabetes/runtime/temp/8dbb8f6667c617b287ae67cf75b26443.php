<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information1.html";i:1556364737;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body style="background-color: #d6ecf0" >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" >糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse" style="border-top-color:#fff;">
  <ul class="nav navbar-nav">   
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>   
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="background-color: #7FD9D6;">
                    <h style="color:#595d5d;; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>" style="color:#595d5d;">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>" style="color:#595d5d;">退出</a></li> 
                </ul>
  </li>      
    <?php endif; ?>
   </ul>
</nav>
<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">糖尿病的早期症状有这5种，你中招了吗？</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   <div class=" col-sm-3 col-xs-8" style="float:left; margin-top:3.5%;"> <img src="/diabetes/public/static/images/information1.jpg" class="img-rounded" style="width:100%; height:135px; overflow:hidden"> </div>
   <p style="font-size:16px;">
 </br>
    &nbsp;&nbsp;&nbsp;&nbsp;我国是糖尿病大国，很多人都不清楚糖尿病的早期症状，以至于糖尿病被诊断时惊慌失措。那么，糖尿病的早期症状有哪些？其实，糖尿病的到来是有迹可循的，糖尿病的早期症状主要有以下5种，赶快看看你是否成为糖尿病的“候选人”！</br>
    </br>
 &nbsp;&nbsp;&nbsp;&nbsp;糖尿病的早期症状一、容易饿，吃得多</br>
 由于体内的糖分被当做尿糖排出体外了，所以吃进去的东西不足以维持身体需要的热量，导致患者总是出现饥饿感，于是大量的吃东西，但是还是感觉到饥肠辘辘，平时不怎么吃甜食的人，也变得开始吃大量的甜食，出现了以上糖尿病的早期症状就需要考虑是不是患上糖尿病，需要及时的去医院就诊。</br>
</br>
　　糖尿病的早期症状二、手发麻，脚抽筋</br>

　　糖尿病人会经常出现手脚麻痹、手脚发抖、手指活动不灵及阵痛感、剧烈的神经炎性脚痛，下肢麻痹、腰痛，不想走路，夜间小腿抽筋、眼运动神经麻痹，重视和两眼不一样清楚，还有自律神经障碍等症状，这些都是糖尿病的早期症状。</br>
</br>
　　糖尿病的早期症状三、感疲劳，尿液白</br>

　　糖尿病患者常常会无缘无故的感觉到疲劳，特别是上下楼的时候更是明显。尿液呈现出白色，有甜酸的气味，如果出现了以上糖尿病的早期症状，一定要及时的去医院就诊，及早发现、及早治疗比较好控制血糖，并且会防止糖尿病并发症的发生。</br>
</br>
　　糖尿病的早期症状四、眼疲劳，视力降</br>

　　糖尿病患者眼睛容易疲劳，视力急剧下降，看不清楚东西，站起来的时候眼前发黑，看东西模糊不清，眼睛忽然变成了近视，出现了老花眼等症状。这是糖尿病会引起的视力障碍、视网膜出血、白内障、视力调节障碍等疾病的明显表现。这个糖尿病的早期症状出现了，就得赶快查血糖和到眼科就诊。</br>
</br>
　　糖尿病的早期症状五、体重降，无他因</br>

　　如果出现了体重不明原因的急剧下降，需要考虑是不是患上了糖尿病，需要及时的去医院就诊。体重下降还可常见于恶性肿瘤、肺结核、甲亢等疾病，排除之后就要考虑是糖尿病，可能是糖尿病的早期症状之一。</br>
</br>
　　了解糖尿病的早期症状是及早发现糖尿病、及早治疗的关键，以上就是小编关于“糖尿病的早期症状”的相关介绍。如果出现上述糖尿病早期症状，赶快去医院查查血糖和糖化血红蛋白吧！
</p>
</div>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>