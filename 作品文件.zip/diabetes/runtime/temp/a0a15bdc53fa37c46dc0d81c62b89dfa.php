<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information2.html";i:1556207369;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body style="background-color: #d6ecf0" >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">    
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>   
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>        
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">AB型血人群罹患2型糖尿病风险高O型血人群低</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
   
 <p style="font-size:16px;">
 </br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;众所周知，肥胖和家族史与2型糖尿病发生风险有关。但是，最新的一项研究提示，血型也可能会影响2型糖尿病发生风险。既往研究表明，血型与卒中风险存在一定的相关性，AB型血的人卒中的风险更高。此外，这些研究中，AB型血的人罹患2型糖尿病风险也较高。</br>
 
　　但这些研究的规模较小，还需要进行大型研究以揭示血型和2型糖尿病之间的关系。为此，来自法国国家健康与医学研究院流行病学和人口健康研究中心的GuyFagherazzi博士等进行了一项大型研究，相关文章发表于2014年12月的Diabetologia杂志中。</br>
 
　　研究者分析了法国E3N研究（始于1990年，纳入近100000名女性的一项研究）中82104名女性的相关数据。通过对这些女性完成的健康问卷的分析，确定了3553名在1990至2008年间确诊的糖尿病患者。随后，对糖尿病患者和非糖尿病者进行随访。</br>
 
　　研究结果显示，与O型血女性相比，A型血和B型血女性发生糖尿病的风险显著增加（分别增加10%和21%）；AB型血女性发生糖尿病的风险相较O型血女性也有一定程度的增加，但差异无统计学意义。</br>
 
　　同时，研究者还评估了Rh因子与糖尿病风险的关系。结果显示，Rh阳性和Rh阴性女性罹患2型糖尿病的风险无显著差异。随后，研究者将ABO血型和Rh因子结合，综合评估血型与2型糖尿病的关系，每种血型组合均与O-型血（O型，Rh阴性）进行对比。研究者发现，与O-型血的女性相比，B+型（B型，Rh阳性）、AB+型、A-型和A+型的女性2型糖尿病发生风险分别增加了35%、26%、22%和17%。</br>
 
　　该研究提示血型与糖尿病风险之间存在明显相关性，O型血的人发生糖尿病的风险更低。因此，有必要进一步进行临床和流行病学研究以探讨血型在糖尿病中所起的作用，并进行病理生理学研究以解释为什么O型血的人发生糖尿病的风险更低。</br>
</div>
</p>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>