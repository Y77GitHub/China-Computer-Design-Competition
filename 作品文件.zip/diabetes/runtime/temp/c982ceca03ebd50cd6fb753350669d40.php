<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"C:\wamp\www\diabetes\public/../application/index\view\index\index.html";i:1556537738;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>糖友之家</title>
    <link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
    <link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
    <script src="/diabetes/public/static/js/index.js"></script> 
    <script src="/diabetes/public/static/js/login.js"></script> 
    <script src="/diabetes/public/static/js/jquery.min.js"></script> 
    <script src="/diabetes/public/static/js/bootstrap.min.js"></script>
    <script type="text/javascript">
            $(function() {
                $('#img').change(function() {
                    var file = this.files[0];
                    var r = new FileReader();
                    r.readAsDataURL(file);
                    $(r).load(function() {
                        $('#photo').html('<img src="' + this.result + '" alt="" />');
                    })
                })
            })

        </script>
        <script language="javascript" >
 
    function show_img1()// 显示图片函数，鼠标移到链接触发
        {document.getElementById("img_1").style.display = "block";}
    function hide_img1()// 隐藏图片函数，鼠标离开链接触发
  {document.getElementById("img_1").style.display = "none";}
   function show_img2()// 显示图片函数，鼠标移到链接触发
        {document.getElementById("img_3").style.display = "block";}
    function hide_img2()// 隐藏图片函数，鼠标离开链接触发
  {document.getElementById("img_3").style.display = "none";}    
   function show_img3()// 显示图片函数，鼠标移到链接触发
        {document.getElementById("img_5").style.display = "block";}
    function hide_img3()// 隐藏图片函数，鼠标离开链接触发
  {document.getElementById("img_5").style.display = "none";}  
</script>

  </head>
  <body style="background-image: url(/diabetes/public/static/images/color3.jpg); background-attachment: fixed; background-repeat: no-repeat; background-size: cover;">
    <!--导航条开始-->
    <nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation"  style="background-color:#7FD9D6;border-bottom-color: #7FD9D6; opacity: 0.9;">

      <div class="container">

        <div class="navbar-header"  id="biaotistyle1">

          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> 
            <span class="sr-only">切换导航</span> 
            <span class="icon-bar"></span> 
            <span class="icon-bar"></span> 
            <span class="icon-bar"></span> 
          </button>
<img src="/diabetes/public/static/images/logo.jpg" class="logostyle" />

         <a class="navbar-brand" id="biaotistyle2">糖友之家</a> 
        </div>
        <div class="collapse navbar-collapse" id="example-navbar-collapse" style="border-top-color:#fff;">
          <ul class="nav navbar-nav">
            <li><a href="#kongbai_tnbzs">糖尿病要点</a></li>
            <li><a href="#kongbai_jkgj">健康工具</a></li>
            <li><a href="#kongbai_yszn">饮食指南</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <?php if(\think\Cookie::get('username') != null): ?>          
              <li class="dropdown" style=" float:center; margin-left:0%; ">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="background-color: #7FD9D6;">
                  <h style="color:#595d5d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>" style="color:#595d5d;">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>" style="color:#595d5d;">退出</a></li> 
                </ul>
              </li> 
            <?php else: ?>
              <li> 
              <!-- 按钮触发模态框 -->
                <button class="glyphicon glyphicon-user btn btn-link" style="margin-top:10%;" data-toggle="modal" data-target="#myModal" > 注册 </button>
              </li>
              <li>
                <button class="glyphicon glyphicon-log-in btn btn-link"  style="margin-top:10%;" data-toggle="modal" data-target="#myModal1" > 登录 </button>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>
          <!-- 注册模态框（Modal开始） -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">× </button>
            <h4 class="modal-title" id="myModalLabel"> 您好，请注册！ </h4>
          </div>
          <form class="form-horizontal" role="form" action="<?php echo url('register'); ?>" method="post">
            <div class="modal-body">                
              <div class="form-group">
                <label for="username" class="col-sm-3 control-label">用户名:</label>
                <div class="col-sm-9">
                  <input style="width: 80%;" type="text"  name="username" id="username" class="form-control well"  placeholder="请输入您喜欢的用户名"  onkeyup="validate2()"/>
                  <span id="tishi2"></span>
                </div>            
              </div>   
              <div class="form-group">
                <label for="password" class="col-sm-3 control-label">密码:</label>
                <div class="col-sm-9">
                  <input style="width: 80%;" type="password" id="password" name="password" class="form-control well"  placeholder="请输入密码（长度在6-12之间）"  onkeyup="validate1()"/>
                  <span id="tishi1"></span>                      
                </div>
              </div>
              <div class="form-group">
                <label for="password" class="col-sm-3 control-label">确认密码:</label>
                <div class="col-sm-9">
                  <input style="width: 80%;" type="password" id="repassword" name="repassword" class="form-control well" placeholder="请再输入密码"  onkeyup="validate()"/>
                  <span id="tishi"></span>
                </div>
              </div>                   
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary" > 注册 </button>
              <button type="button" class="btn btn-default"  data-dismiss="modal">返回 </button>                 
            </div>
          </form> 
        </div>
      </div>
    </div>
    
    <!-- 登录模态框（Modal） -->
    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"  aria-hidden="true">× </button>
            <h4 class="modal-title" id="myModalLabel">   您好，请登录！</h4>
          </div>
          <form class="form-horizontal" role="form" action="<?php echo url('login'); ?>" method="post">
            <div class="modal-body">                
              <div class="form-group">
                  <label for="name" class="col-sm-3 control-label">用户名:</label>
                  <div class="col-sm-9">
                    <input style="width: 80%;" type="text" id="username" name="username" class="form-control well" placeholder="请输入您的用户名" /><!-- onkeyup="revalidate4()" -->
                    <!-- <span id="tishi4"></span> -->
                  </div>
              </div>
              <div class="form-group">
                <label for="pass" class="col-sm-3 control-label">密码:</label>
                  <div class="col-sm-9">
                    <input style="width: 80%;" type="password" id="password" name="password" class="form-control well" placeholder="请输入密码" /><!-- onkeyup="revalidate3()" -->
                    <!-- <span id="tishi3"></span> -->
                  </div>
              </div>
              <div class="form-group">
                <label for="captcha" class="col-sm-3 control-label">验证码:</label>
                <div class="col-sm-9">
                  <input style="width: 30%" type="text" placeholder="验证码" name="captcha" class="form-control well"/>
                    <img style="margin-top: -13%; float: left; margin-left: 35%;" src="<?php echo captcha_src(); ?>" class="verify" onclick="javascript:this.src='<?php echo captcha_src(); ?>?rand='+Math.random()" >
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary"> 登录 </button>
              <button type="button" class="btn btn-default" data-dismiss="modal">取消 </button>
            </div>
          </form>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- 模态框（Modal）结束 --> 

    <!--轮播图开始-->
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        <li data-target="#carousel-example-generic" data-slide-to="3"></li>
        <li data-target="#carousel-example-generic" data-slide-to="4"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active"> <img id="picturestyle" src="/diabetes/public/static/images/rotation_chart1.jpg"> </div>
        <div class="item"> <img id="picturestyle" src="/diabetes/public/static/images/rotation_chart2.jpg" > </div>
        <div class="item"> <img id="picturestyle" src="/diabetes/public/static/images/rotation_chart3.jpg" > </div>
        <div class="item"> <img id="picturestyle" src="/diabetes/public/static/images/rotation_chart4.jpg" > </div>
        <div class="item"> <img id="picturestyle" src="/diabetes/public/static/images/rotation_chart5.jpg"> </div>
      </div>
      <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev"> 
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> 
        <span class="sr-only">上一页</span> 
      </a> 
      <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next"> 
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span> 
        <span class="sr-only">下一页</span> 
      </a> 
    </div>
    <!--轮播图结束--> 
    <!--导航条结束--> 

    <!--糖尿病知识开始-->
    <div id="kongbai_tnbzs"></div>
    <div style="width:90%; height:400px; margin-left:5%; margin-right:5%; margin-top:3%; margin-bottom:2%;"> 
      <!--糖尿病知识标题开始-->
      <div class="position">
        <div class="svg-wrapper"> 
          <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
            <rect id="shape" height="40" width="150" />
            <div id="text"> 
              <a href="">
                <span class="spot"></span>
                <p style="text-align: center;">糖尿病要点</p>
              </a> 
            </div>
          </svg> 
        </div>
      </div>
      <!--糖尿病知识标题结束--> 
      <!--糖尿病知识内容开始-->
      <div class="panel panel-info col-md-4 col-xs-12"  style="margin-left:2%; margin-right:0.5%; margin-top:1%; float:left;height:335px;border:2px solid #8BDBE3;">
        <div class="panel-heading">
          <h3 class="panel-title" style=" text-align:center;">糖尿病新闻</h3>
        </div>
        <div class="panel-body " >     
          <ul style="padding-left: 1px;text-align: center;">
            <li><a href="<?php echo url('information1'); ?>"><p class="content" style="font-size: 15px;">糖尿病的早期症状有这5种，你中招了吗？</p></a></li>
            <li><a href="<?php echo url('information2'); ?>"><p class="content" style="font-size: 15px;">AB型血人群罹患2型糖尿病风险高O型血人群低</p></a></li>
            <li><a href="<?php echo url('information3'); ?>"><p class="content" style="font-size: 15px;">礼来糖尿病领域再发力与Adocia合作研发“超速效胰岛素”</p></a></li>
            <li><a href="<?php echo url('information4'); ?>"><p class="content" style="font-size: 15px;">英国一项最新研究通过吹气可测是否患1型糖尿病</p></a></li>
            <li><a href="<?php echo url('information5'); ?>"><p class="content" style="font-size: 15px;">2型糖尿病患者牙周病与糖尿病肾病的相关性分析</p></a></li>
            <li><a href="<?php echo url('information6'); ?>"><p class="content" style="font-size: 15px;">糖尿病会增加肝切除术后急性肾衰及败血症发生风险</p></a></li>
            <li><a href="<?php echo url('information7'); ?>"><p class="content" style="font-size: 15px;">Regeneron糖尿病视网膜病变药Eylea获FDA优先审查权</p></a></li>
            <li><a href="<?php echo url('information8'); ?>"><p class="content" style="font-size: 15px;">1型糖尿病早期症状有哪些？夏季糖尿病人需要注意什么？</p></a></li>
            <li><a href="<?php echo url('information9'); ?>"><p class="content" style="font-size: 15px;">糖尿病的早期症状有哪些？警惕糖尿病的18种早期症状</p></a></li>
          </ul>
        </div>
      </div>
      <div class="panel panel-info  col-md-6 col-lg-7"  style="margin-left:3.5%;  margin-top:1%; float:left;border:2px solid #8BDBE3; ">
        <div class="panel-body">
          <div class="col-sm-3 col-xs-6" style="float:left; ">
            <img class="imgstyle" src="/diabetes/public/static/images/1.jpg" class="img-rounded " />
            <div class="box-content1">
              <a href="<?php echo url('knowledge1'); ?>"><h3 class="description">控制饮食<br/>战胜糖尿病</h3></a>
            </div> 
          </div>
          <div class="col-sm-3 col-xs-6" style=" float:left; ">
            <img class="imgstyle" src="/diabetes/public/static/images/2.jpg" class="img-rounded" /> 
            <div class="box-content1">
              <a href="<?php echo url('knowledge2'); ?>"><h3 class="description">糖尿病能吃燕麦吗</h3></a>
            </div>
          </div>
          <div class="col-sm-3 col-xs-6" style="float:left;">
            <img class="imgstyle" src="/diabetes/public/static/images/3.jpg" class="img-rounded" />
            <div class="box-content1">
              <a href="<?php echo url('knowledge3'); ?>"><h3 class="description">推荐五种<br/>降血糖食物</h3></a>
            </div>
          </div>
          <div class="col-sm-3 col-xs-6" style=" float:left; "> 
            <img class="imgstyle" src="/diabetes/public/static/images/4.jpg" class="img-rounded"/> 
            <div class="box-content1">
              <a href="<?php echo url('knowledge4'); ?>"><h3 class="description">吃甜食多<br/>就会得糖尿病吗</h3></a>
            </div>
          </div>
          <div class="col-sm-3 col-xs-6" style="float:left; margin-top:5%;"> 
            <img class="imgstyle" src="/diabetes/public/static/images/5.jpg" class="img-rounded" /> 
            <div class="box-content1">
              <a href="<?php echo url('knowledge5'); ?>"><h3 class="description">糖尿病患者<br/>需要控制喝水吗</h3></a>
            </div>
          </div>
          <div class="col-sm-3 col-xs-6" style=" float:left;  margin-top:5%;"> 
            <img class="imgstyle" src="/diabetes/public/static/images/6.jpg" class="img-rounded" /> 
            <div class="box-content1">
              <a href="<?php echo url('knowledge6'); ?>"><h3 class="description">糖尿病患者<br/>需要补硒吗</h3></a>
            </div>
          </div>
          <div class="col-sm-3 col-xs-6" style=" float:left; margin-top:5%;"> 
            <img class="imgstyle" src="/diabetes/public/static/images/7.jpg" class="img-rounded" /> 
            <div class="box-content1">
              <a href="<?php echo url('knowledge7'); ?>"><h3 class="description">糖尿病饿了<br/>吃什么好</h3></a>
            </div>
          </div>
          <div class="col-sm-3 col-xs-6" style="float:left;  margin-top:5%;"> 
            <img class="imgstyle" src="/diabetes/public/static/images/8.jpg" class="img-rounded" />
            <div class="box-content1">
              <a href="<?php echo url('knowledge8'); ?>"><h3 class="description">糖尿病饮食治疗<br/>的一般原则</h3></a>
            </div>
          </div>               
        </div><!-- panel-body结束 -->
      </div><!-- panel结束 -->
      <!--糖尿病知识内容结束--> 
    </div><!--糖尿病知识结束--> 

    <!--健康工具开始-->
    <div id="kongbai_jkgj"></div>
      <div style="width:90%;margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%;  height: 200px">
        <div class="position">
          <div class="svg-wrapper"> 
            <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
              <rect id="shape" height="40" width="150" />
              <div id="text"> <a href=""><span class="spot"></span><p style="text-align: center;">健康工具</p></a> </div>
            </svg> 
          </div>
        </div>
        <div class="col-md-3 col-xs-6" style="float:left; margin-top:5%;"> 
          <div class="box1">
            <img src="/diabetes/public/static/images/BMI.jpg" class="img-circle col-xs-6"/>
            <div class="box-content">
              <div class="content">
                <h3 class="title">身体质量指数(BMI)</h3>
                <span class="post">衡量人体胖瘦程度以及是否健康</span>
                <ul class="icon">
                  <li><a href="<?php echo url('countbmi'); ?>"><i></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-xs-6" style="float:left; margin-top:5%;"> 
          <div class="box1">
            <img src="/diabetes/public/static/images/standard_weight_range.jpg" class="img-circle col-xs-6" />
            <div class="box-content">
              <div class="content">
                <h3 class="title">健康体重范围</h3>
                <span class="post">了解自身标准体重范围</span>
                <ul class="icon">
                  <li><a href="<?php echo url('healthyweightscope'); ?>"><i></i></a></li>
                </ul>
              </div>
            </div>
          </div> 
        </div>
        <div class="col-md-3 col-xs-6" style="float:left; margin-top:5%;"> 
          <div class="box1">
            <img src="/diabetes/public/static/images/basic_metabolism.jpg" class="img-circle col-xs-6"/>
            <div class="box-content">
              <div class="content">
                <h3 class="title">基础代谢计算</h3>
                <span class="post">了解自己代谢情况</span>
                <ul class="icon">
                  <li><a href="<?php echo url('basicmetabolismcalculation'); ?>"><i></i></a></li>
                </ul>
              </div>
            </div>
          </div> 
        </div>
        <div class="col-md-3 col-xs-6" style="float:left; margin-top:5%;"> 
          <div class="box1">
            <img src="/diabetes/public/static/images/blood_glucose.jpg" class="img-circle col-xs-6"/>
            <div class="box-content">
              <div class="content">
                <h3 class="title">记录血糖</h3>
                <span class="post">记录自身血糖情况</span>
                <ul class="icon">
                  <li><a href="<?php echo url('bloodsugarrecord'); ?>"><i></i></a></li>
                </ul>
              </div>
            </div>
          </div> 
        </div>
      </div>
      <!--健康工具结束-->
      <!--饮食指南开始-->
      <div id="kongbai_yszn"  style="margin-top: 10%;"></div>
      <div class="col-xs-12" style="width:90%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
        <div class="position" >
          <div class="svg-wrapper"> 
            <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
              <rect id="shape" height="40" width="150" />
              <div id="text"> <a href=""><span class="spot"></span><p style="text-align: center;">饮食指南</p></a> </div>
            </svg> 
          </div>
        </div>        
        <div style="margin-left:2%; margin-right:2%; margin-top:1%;width:96%; margin-bottom:1%; height:89%; ">
          <ul id="myTab" class="nav nav-tabs"><!--身体质量指数(BMI),基础代谢计算,健康体重范围,记录早晚血糖-->
            <li class="active"><a href="#home" data-toggle="tab">控糖药膳</a></li>
            <li><a href="#jmeter" data-toggle="tab">推荐食谱</a></li>
            <li><a href="#eat" data-toggle="tab">饮食记录</a></li>
          </ul>
          <div id="myTabContent" class="tab-content">
            <div class="tab-pane fade in active" id="home">
              <div class="container" style="border-top:2px solid #8BDBE3;">
  <div class="container mt50" >
    <div class="row" style="margin-left: -3%;">
      <div class="col-sm-3 col-xs-6" style="float:left;text-align:center; ">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/spinach_root_porridge.jpg"  alt="" style="border-radius:10%;">
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
菠菜根粥
</div>
          <div class="over-layer">
            <h6 class="title" >[食材]鲜菠菜根250克，鸡内金10克，大米适量</br>[制作]菠菜根洗净切碎，与鸡内金加水适量煎煮半小时，再加入淘净的大米，煮烂成粥。</br>[疗效]补虚，止烦消渴，适用于糖尿病口渴，多饮不止以及热病伤阴。</br>[用法] 每日l一2次服食。</h6>
            
          </div>
        </div>
      </div>

      <div class="col-sm-3  col-xs-6" style="float:left;text-align:center; ">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/ginseng_qi_tea.jpg" alt=""  style="border-radius:10%;">
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
参杞茶
</div>
          <div class="over-layer">
            <h6 class="title" >[食材]西洋参，枸杞子，红枣，黄芪</br>[制作]将人参片、枸杞放入锅中，加500毫升水煮沸后，转小火续煮2吩钟即成。</br>[疗效]健脾气，利水湿，补阴益髓。</br>[用法] 每日l一2次服食。</h6>
            
          </div>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6" style="float:left;text-align:center; ">
        <div class="box" style="position:relative;">
          <img src="/diabetes/public/static/images/desert_cistanche_mutton.jpg" alt="" style="border-radius:10%;" >
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
苁蓉羊肉
</div>
          <div class="over-layer">
            <h6 class="title"  >[食材]羊肉60克，肉苁蓉30克，菟丝子15克</br>[制作]把全部用料放人炖盏内，开水稳火炖2--3小时。</br>[疗效]补肾益精，保肝护，男性阳痿、早泄，女性月经不调、宫寒等有很好的调理作用。</br>[用法] 每周l一2次服食。</h6>
            
          </div>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6" style="float:left;text-align:center; ">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/wong_porridge.jpg" alt="" style="border-radius:10%;">
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
黄精粥
</div>
          <div class="over-layer">
            <h6 class="title" >[食材]黄精30g、粳米100g，冰糖适量</br>[制作]黄精煎水取汁，入粳米煮至粥熟。加冰糖适量吃。</br>[疗效]适用于脾胃亏虚，肢软乏力，于阴虚肺燥，咳嗽咽干，脾胃虚弱。</br>[用法]每日食二次，以3～5天为一疗程。</h6>
            
          </div>
        </div>
      </div>
      
      <div class="col-sm-3 col-xs-6"  style="float:left; margin-top:2%;text-align:center;">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/astragalus_yam_porridge.png" alt="" style="border-radius:10%;">
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
黄芪山药粥
</div>
          <div class="over-layer">
            <h6 class="title">[食材]黄芪30克，山药60克研粉</br>[制作] 将山药研粉，黄芪水煎取汁300毫升，加入山药粉搅匀煮成粥。</br>[疗效]益气生津，健脾固肾。适用于糖尿病久而不愈、体质虚弱、腹泻便溏、畏寒肢冷等症。</br>[用法] 每日l一2次服食。</h6>
            
          </div>
        </div>
      </div>

      <div class=" col-sm-3 col-xs-6"  style="float:left; margin-top:2%;text-align:center;">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/astragalus_oat_porridge.jpg" alt="" style="border-radius:10%;">
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;text-align:center;top:80%;color:black">
黄芪燕麦粥
</div>
          <div class="over-layer">
            <h6 class="title" >[食材]黄芪10克，燕麦50克</br>[制作]两者共煮粥常服。</br>[疗效]益气补虚，健脾补肾，养胃，降脂，尤其适用于糖尿病合并脂肪肝，冠心病，高血压以及糖尿病人虚汗，盗汗者。</br>[用法] 每日l一2次服食。</h6>
            
          </div>
        </div>
      </div>

      <div class=" col-sm-3 col-xs-6"  style="float:left; margin-top:2%;text-align:center;">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/white_pigeon_soup.jpeg" alt="" style="border-radius:10%;" >
          <div   class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
山药玉竹白鸽汤
</div>
          <div class="over-layer">
            <h6 class="title" >[食材]淮山药30克，玉竹30克，麦冬30克，白鸽1只</br>[制作]用料一齐放入瓦锅内，加清水适量。</br>[疗效]适用于糖尿病。</br>[用法] 每周l一2次服食。</h6>
            
          </div>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6"  style="float:left; margin-top:2%;text-align:center;">
        <div class="box" style="position:relative;">
          <img  src="/diabetes/public/static/images/clay_duck_nuts.jpeg"  alt="" style="border-radius:10%;">
          <div  class="content" style="position:absolute;width:100%;height:100%;z-indent:2;top:80%;color:black">
芡实煲老鸭
</div>
          <div class="over-layer">
            <h6 class="title"  >[食材]芡实100～120 克，老鸭一只</br>[制作]将芡实放入鸭腹中，置瓦罐内，加清水适量，文火煮2小时左右，调味服用。</br>[疗效]补虚,适用于糖尿病。</br>[用法] 每周l一2次服食。</h6>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
                
            </div>
            <div class="tab-pane fade" id="jmeter">
              <div class="panel-group" id="accordion" style="border-top:2px solid #8BDBE3;">
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion"  href="#collapseOne">
                        糖尿病人星期一推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse ">
                    <div class="panel-body">
                      早餐：窝头1个(50克)，牛奶1杯(250毫升)，鸡蛋1个，凉拌豆芽1小蝶。</br>
                      午餐：米饭一碗(100克)，雪菜豆腐，肉丝炒芹菜。</br>
                      晚餐：馒头1个(100克)，盐水大虾，鸡片炒油菜。
                    </div>
                  </div>
                </div>
                <div class="panel panel-success">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                        糖尿病人星期二推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseTwo" class="panel-collapse collapse">
                    <div class="panel-body">
                      早餐：全麦面包片(50克)，豆浆1杯(400毫升)，茶鸡蛋1个，凉拌苦瓜1小蝶。</br>
                      午餐：烙饼2块(100块)，口蘑冬瓜，牛肉丝炒胡萝卜。</br>
                      晚餐：米饭1碗(100克)，鸡汤豆腐小白菜，清炒虾仁黄瓜。
                    </div>
                  </div>
                </div>
                <div class="panel panel-info">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                        糖尿病人星期三推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseThree" class="panel-collapse collapse">
                    <div class="panel-body">
                       早餐：蔬菜包子1个(50克)，米粥1碗，鸡蛋1个，拌白菜心1小蝶。</br>
                       午餐：荞麦面条1碗(100克)，西红柿炒鸡蛋，素鸡菠菜。</br>
                       晚餐：紫米馒头1个(100克)，香菇菜心，沙锅小排骨。
                    </div>
                  </div>
                </div>
                <div class="panel panel-warning">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion"  href="#collapseFour">
                        糖尿病人星期四推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseFour" class="panel-collapse collapse">
                    <div class="panel-body">
                      早餐：豆包1个(50)，荷叶绿豆粥1碗，鸡蛋1个，凉拌三丝1小蝶。</br>
                      午餐：玉米面馒头1个(100克)，炒鱿鱼卷芹菜，素烧茄子。</br>
                      晚餐：米饭1碗(100克)，葱花烧豆腐，椒油圆白菜。
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion"  href="#collapseFive">
                        糖尿病人星期五推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseFive" class="panel-collapse collapse ">
                    <div class="panel-body">
                      早餐：牛奶燕麦粥(牛奶250毫升，燕麦25克)，鸡蛋羹(鸡蛋1个)，海米拌芹菜1小蝶。</br>
                      午餐：荞麦大米饭1碗(100克)，青椒肉丝，香菇豆腐汤。</br>
                      晚餐：花卷1个(100克)，醋椒鱼，西红柿炒扁豆。
                    </div>
                  </div>
                </div>
                <div class="panel panel-success">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
                        糖尿病人星期六推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseSix" class="panel-collapse collapse">
                    <div class="panel-body">
                      早餐：全麦小馒头1个(50克)，薏苡仁粥1碗，鸡蛋1个，拌莴笋丝1小蝶。</br>
                      午餐：茭白鳝丝面(含面条100克)，醋溜大白菜。</br>
                      晚餐：葱油饼(含面粉100克)，芹菜香干，紫菜冬瓜汤。
                    </div>
                  </div>
                </div>
                <div class="panel panel-info">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion"  href="#collapseSeven">
                        糖尿病人星期天推荐食谱
                      </a>
                    </h4>
                  </div>
                  <div id="collapseSeven" class="panel-collapse collapse">
                    <div class="panel-body">
                      早餐：牛奶240ml，鸡蛋1个，馒头50克</br>
                      午餐：烙饼150克，酱牛肉80克，醋烹豆芽菜</br>
                      晚餐：米饭150克，肉末烧豆腐，蒜茸菠菜
                    </div>
                  </div>
                </div>
              </div><!-- panel-group结束 -->
            </div><!-- tab-pane fade结束 -->
            <div class="tab-pane fade" id="eat">
              <div class="tabs-vertical col-xs-12 col-lg-12" style="height:100%;border:2px solid #8BDBE3;" >
                <ul>
                  <li><a class="tab-active" data-index="0" href="#">早餐</a></li>
                  <li><a data-index="1" href="#">午餐</a></li>
                  <li><a data-index="2" href="#">晚餐</a></li>                    
                  <li><a data-index="3" href="#">加餐</a></li>                                        
                </ul>
                <div class="tabs-content-placeholder" style="height:100%;">
                  <div class="tab-content-active" >          
                    <p style="text-align:center; ">添加早餐饮食记录，以便更好的找到血糖管理规律 </p>
                      <form action="<?php echo url('breakfast'); ?>" method="post" enctype="multipart/form-data"> 
                        <section class="rdiates" >
                      <textarea name="breakfast_record" type="text"  size="200"  placeholder="描述下你吃的早餐食物，如包子1个（90克），鸡蛋一个（50克）" style=" border-radius:5px;border:1px solid #000; float: left;  width:200px; height:200px;" cols="2"   rows="6"   style="OVERFLOW:   hidden"></textarea>
                      <h5 style="  float: left; margin-top:0%; margin-left:2%;">请添加早餐图片:</h5>
                      <input name="breakfast_images" type="file" id="upfile1" class="social-life1" size="40"  style="float: left; margin-left:3%;" onchange="viewmypic1(showing1,this.form.upfile1);"/>
                      <img name="showing1" src="" style="display:none; width:200px;height:170px;float: left;  margin-left:-22%;margin-top:3%"  alt="预览图片" />
                      <h5 style="float: left; margin-top:0%;">请选择日期(<strong style="font-size: 17px;">必填</strong>):</h5>
                      <input type="text"  style="float:left; " name="time" onclick="SelectDate(this,'yyyy-MM-dd')"/>
                      </section>
                     <hr style="border:3px  solid #e9e7ef;"/>
                    
                       <p style="text-align:center">记录早餐前后的血糖，以便更好的管理血糖</p>
                      <p style="text-align:center">早餐前：<input type="decimal" name="breakfast_before" />
                      &nbsp;&nbsp;mol/L</p>
                      <p style="text-align:center">早餐后：<input type="decimal" name="breakfast_after"/>
                      &nbsp;&nbsp;mmol/L</p>
                      <input type="submit" value="保存" />
                 
                    </form>
                  </div>        
                  <div>
                    <p style="text-align:center;"> 添加午餐饮食记录，以便更好的找到血糖管理规律</p>
                    <form action="<?php echo url('lunch'); ?>" method="post" enctype="multipart/form-data">  
                      <section class="rdiates" >                  
                      <textarea  id="lunch_record" type="text"  size="50" name="lunch_record" placeholder="描述下你吃的午餐食物，如米饭100克，炒牛肉50克" style=" border-radius:5px;border:1px solid #000; float: left; width:200px; height:200px;" cols="2"   rows="6"   style="OVERFLOW:   hidden"></textarea>
                      <h5 style="  float: left; margin-top:0%; margin-left:2%;">请添加午餐图片:</h5>        
                      <input name="lunch_images" type="file" id="upfile1" class="social-life1" size="40"  style="float: left; margin-left:3%;" onchange="viewmypic1(showing1,this.form.upfile1);"/>
                      <img name="showing1" src="" style="display:none; width:200px;height:170px;float: left; margin-left:-22%; margin-top:3% "  alt="预览图片" />
                      <h5 style=" float: left; margin-top:0%;">请选择日期(<strong style="font-size: 17px;">必填</strong>):</h5>
                      <input type="text"  style="float:left; margin-top:0%" name="time" onclick="SelectDate(this,'yyyy-MM-dd')"/>                              
                      </section>
                     <hr style="border:3px  solid #e9e7ef;"/>

                      <p style="text-align:center">记录午餐前后的血糖，以便更好的管理血糖</p>                                  
                      <p style="text-align:center">午餐前：<input type="decimal" name="lunch_before" />
                      &nbsp;&nbsp;mmol/L</p>
                      <p style="text-align:center">午餐后：<input type="decimal" name="lunch_after"/>
                      &nbsp;&nbsp;mmol/L</p>
                      <input type="submit" value="保存" />
                    </form>
                  </div>
                  <div>
                    <p style="text-align:center; ">添加晚餐饮食记录，以便更好的找到血糖管理规律</p>
                    <form action="<?php echo url('dinner'); ?>" method="post" enctype="multipart/form-data">
                      <section class="rdiates" >
                      <textarea  id="dinner_record" type="text" name="dinner_record" size="50"  placeholder="描述下你吃的晚餐食物，如紫薯150克，青菜150克" style=" border-radius:5px;border:1px solid #000; float: left; width:200px; height:200px;" cols="2"   rows="6"   style="OVERFLOW:   hidden"></textarea>
                      <h5 style="float: left; margin-top:0%; margin-left:2%;">请添加晚餐图片:</h5>
                      <input name="dinner_images" type="file" id="upfile1" class="social-life1" size="40"  style="float: left; margin-left:3%;" onchange="viewmypic1(showing1,this.form.upfile1);"/>
                      <img name="showing1" src="" style="display:none;width:200px;height:170px;float: left; margin-left:-22%; margin-top:3%"  alt="预览图片" />
                      <h5 style="float: left; margin-top:0%;">请选择日期(<strong style="font-size: 17px;">必填</strong>):</h5>
                      <input type="text"  style="float:left; margin-top:0%;" name="time" onclick="SelectDate(this,'yyyy-MM-dd')"/>
                      </section>
                     <hr style="border:3px  solid #e9e7ef;"/>

                      <p style="text-align:center">记录晚餐前后的血糖，以便更好的管理血糖</p>                          
                      <p style="text-align:center">晚餐前：<input type="decimal" name="dinner_before" />
                      &nbsp;&nbsp;mmol/L</p>
                      <p style="text-align:center">晚餐后：<input type="decimal" name="dinner_after"/>
                      &nbsp;&nbsp;mmol/L</p>
                      <input type="submit" value="保存" />
                    </form>
                  </div>
                  <div>
                    <p style="text-align:center; ">添加加餐饮食记录，以便更好的找到血糖管理规律</p>
                    <form action="<?php echo url('extra_meal'); ?>" method="post" enctype="multipart/form-data">
                      <section class="rdiates" >
                      <textarea id="extra_meal_record" type="text" name="extra_meal_record" size="50"  placeholder="描述下你吃的加餐食物，如苹果200克" style=" border-radius:5px;border:1px solid #000; float: left;width:200px; height:200px;" cols="2"   rows="6"   style="OVERFLOW:   hidden"></textarea>
                      <h5 style=" float: left; margin-top:0%; margin-left:2%;">请添加加餐图片:</h5>                 
                      <input name="extra_meal_images" type="file" id="upfile1" class="social-life1" size="40" style="float: left; margin-left:3%;" onchange="viewmypic1(showing1,this.form.upfile1);"/><img name="showing1" src="" style="display:none; width:200px;height:170px;float: left;  margin-left:-22%;margin-top:3%"  alt="预览图片" />
                      <h5 style=" float: left; margin-top:0%; ">请选择日期(<strong style="font-size: 17px;">必填</strong>):</h5>
                      <input type="text"  style="float:left; margin-top:0%;" name="time" onclick="SelectDate(this,'yyyy-MM-dd')"/> 
                      </section>
                     <hr style="border:3px  solid #e9e7ef;" />
                      <p style="text-align:center">记录加餐前后的血糖，以便更好的管理血糖</p>                   
                     <p style="text-align:center">加餐前：<input type="decimal" name="extra_meal_before" />
                      &nbsp;&nbsp;mmol/L</p>
                      <p style="text-align:center">加餐后：<input type="decimal" name="extra_meal_after"/>
                      &nbsp;&nbsp;mmol/L</p>
                      <input type="submit" value="保存" />
                    </form>         
                  </div>
                </div><!-- tabs-content-placeholder结束 -->
              </div><!-- tabs-vertical结束 -->        
            </div><!-- tab-pane fade结束 -->
          </div><!-- tab-content结束 -->
        </div><!-- 饮食指南内容结束 -->
      </div><!--饮食指南结束--> 

      <!--关于我们开始-->
      <div id="kongbai_gywm"></div>
      <div class="footer-box col-xs-12 col-lg-12" style="width:100%;background:#222;">
        <div class="footer f-cb ">
          <div class="footer-left col-xs-12 col-lg-8" id="leftstyle">
            <p style="font-size: 25px;">联系我们</p>
            <div align="center" style="height: 100px;float: left;" class=" col-md-4 col-xs-1"> <a  onMouseOver="show_img1()" onMouseOut="hide_img1()" > <img id="img_2"  src="/diabetes/public/static/images/qq.jpg" class="qqstyle1" /></a>
  <div align="center" class="qqstyle3" ><img id="img_1"   src="/diabetes/public/static/images/qqerweima.jpg" class="qqstyle2" /> </div>
</div>

<div align="center" style="height: 100px;float: left;" class="col-md-4 col-xs-1"> <a  onMouseOver="show_img2()" onMouseOut="hide_img2()" > <img id="img_4"  src="/diabetes/public/static/images/weixin.jpg" class="weixinstyle1" /></a>
  <div align="center" class="weixinstyle3" ><img id="img_3"   src="/diabetes/public/static/images/weixinerweima.jpg" class="weixinstyle2" /> </div>
</div>

 <div align="center" style="height: 100px;float: left;" class="col-md-4 col-xs-1"> <a onMouseOver="show_img3()" onMouseOut="hide_img3()" > <img id="img_6"  src="/diabetes/public/static/images/weibo.jpg" class="weibostyle1"/></a>
  <div align="center" class="weibostyle3" ><img id="img_5"   src="/diabetes/public/static/images/weiboerweima.jpg" class="weibostyle2"  /> </div>
</div>
          </div>
          <div class="footer-right col-xs-12 col-lg-4" id="rightstyle" >
            <dl class="friend-link ">
              <dt>友情链接</dt>
              <br/>
              <dd><a href='http://www.diab.net.cn/cn/index.aspx' target='_blank'>中华医学会糖尿病学分会</a> </dd>
              <dd><li><a href="https://www.cma.org.cn/">中华医学会</a></li></dd>
            </dl>
           
          </div>
        </div>
      </div>
      <!--关于我们结束-->

      <div id="scroll" ></div>
      <!-- 置顶图标 -->


<script type="text/javascript">
    // 获取置顶对象
    var obj = document.getElementById('scroll');
    var scrollTop = null;
 
    // 置顶对象点击事件
    obj.onclick = function() {
        var timer = setInterval(function() {
            window.scrollBy(0, -100);
            if (scrollTop == 0) 
                clearInterval(timer);
        }, 2);
    }
 
    // 窗口滚动检测
    window.onscroll = function() {
        scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
        obj.style.display = (scrollTop >= 300) ? "block" : "none";
    }
</script> 
</body>
</html>