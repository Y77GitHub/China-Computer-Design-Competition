<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:51:"C:\wamp\www\diabetes\thinkphp\tpl\dispatch_jump.tpl";i:1555738590;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <title>跳转提示</title>
    <style>
*{margin:0;padding:0;}
.tip{width: 50%; min-height: 200px; margin: 0 auto; margin-top: 10%; } 
.tip h1{font-size: 20px; text-align: center; color: #333; } 
.tip a{color: #777; font-size: 22px; } 
.tip span{color: #080808; font-size: 22px; } 
.tip h2{color:green; text-align:center; font-size:30px;margin-top:20px;} 
.tip h3{color:red; text-align:center; font-size:30px;margin-top:20px;} 
@media screen and (max-width: 1400px) { 
    .tip img{width:280px;}
}
</style>
</head>

<body>
<div class="tip">
    <h1>页面自动<a id="href" href="<?php echo($url);?>">跳转</a>等待时间：<span><b id="wait"><?php echo($wait);?></b></span></h1>
    <?php switch ($code) {case 1:?>
        <!-- 提交成功 -->
        <h2><?php echo(strip_tags($msg));?></h2>
        <!-- <img src="/diabetes/public/static/images/success.jpg" alt=""> -->
        <?php break;case 0:?>
        <!-- 提交失败 -->
        <h3><?php echo(strip_tags($msg));?></h3>
        <!-- <img src="/diabetes/public/static/images/error.png" alt=""> -->
        <?php break;} ?>
</div>

<script type="text/javascript">
        (function(){
            var wait = document.getElementById('wait'),
                href = document.getElementById('href').href;
            var interval = setInterval(function(){
                var time = --wait.innerHTML;
                if(time <= 0) {
                    location.href = href;
                    clearInterval(interval);
                };
            }, 1000);
        })();
    </script>
</body>
</html>