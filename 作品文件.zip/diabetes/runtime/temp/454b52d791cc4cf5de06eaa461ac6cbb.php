<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp\www\diabetes\public/../application/index\view\information\information7.html";i:1556009057;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>糖尿病要点</title>
<link href="/diabetes/public/static/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/index.css">
<link rel="stylesheet" type="text/css" href="/diabetes/public/static/css/饮食管理中的图片样式设计.css">
</head>
<body >
<!--导航条开始-->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation" >
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand">糖尿病新闻</a> </div>
  <div class="collapse navbar-collapse" id="example-navbar-collapse">
  <ul class="nav navbar-nav">
    
    <li><a href="<?php echo url('information'); ?>">返回主页</a></li>
    
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <?php if(\think\Cookie::get('username') != null): ?>
    <li class="dropdown" style=" float:center; margin-left:0%; ">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- <img src="/diabetes/public/static/images/user_logo.jpg" style="width:30%; height:30%; vertical-align: middle;"/> -->
                    <h style="color:#9d9d9d; font-size: 16px;"> 你好,<?php echo \think\Cookie::get('username'); ?>&nbsp;<b class="caret" style="float:right; "></b></h>
                    
                </a>
                <ul class="dropdown-menu">
                  <li ><a href="<?php echo url('myinfo'); ?>">我的信息&nbsp;&nbsp;<img src="/diabetes/public/head_sculpture/<?php echo $data['head_sculpture']; ?>" style="width:45px; vertical-align: middle;border-radius:50%;"/></a></li>
                  <li><a href="<?php echo url('logout'); ?>">退出</a></li> 
                </ul>
  </li>     
    <?php endif; ?>
   </ul>
</nav>



<!--糖尿病知识开始-->

<div class="yszn" style="width:90%; height:100%; margin-left:5%; margin-right:5%; margin-top:5%; margin-bottom:2%; ">
  <h3 style="text-align:center">Regeneron糖尿病视网膜病变药Eylea获FDA优先审查权</h3>
  <div class="panel panel-info col-md-4"  style="margin-left:5%; margin-right:5%; margin-top:1%;width:90%; float:left;height:100%; ">
 <p style="font-size:16px;">
 </br>
  　&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Regeneron近日宣布，FDA已经决定授予该公司补充生物制剂许可证申请的优先审核权，这为Regeneron看家药物Eylea（用于治疗糖尿病黄斑水肿病人的糖尿病视网膜病变）的品牌扩张提供了优势条件。 </br>
 
　　FDA的优先审核权主要是授予治疗那些严重疾病或是易被忽视疾病的药物，享有此项优先权的药物可以由原来的十个月审核期缩短至六个月，因此，依据处方药使用者收费法案，Eylea的批准日期预计为2015年3月30号。 </br>
 
　　今年9月份，Eylea已经获得了突破性疗法认定（相关阅读：FDA授予拜耳Eylea突破性疗法认定——有望成为首个糖尿病性视网膜病变（DR）药物），突破性疗法认定主要是授予那些对某种特定疾病具有临床前活性的药物，拥有该认证将会大大加速FDA对该药物的审批和指南认定。 </br>
 
　　糖尿病视网膜病变是具有十年以上糖尿病病史的患者的多发病，糖尿病患者血液成分的改变，而引起血管内皮细胞功能异常，使血-视网膜屏障受损，进而导致组织缺氧和糖尿病黄斑水肿（DME），最终引起视力丧失。DME是糖尿病引起的视网膜上液体聚集和黄斑水肿，而人的视力主要依赖视网膜，由此视力便会下降乃至丧失。 </br>
 
　　糖尿病是美国地区的多发病，据美国CDC统计，将近2900万人（占人口总数9%）患糖尿病，其中28%的40岁以上患者并发糖尿病视网膜病变或其他由糖尿病引起的视力减退，而DME是这些患者视力丧失的主要原因。 </br>
 
　　Eylea是一种注射性的血管内皮生长因子抑制剂，可以预防新生血管生成。该药品已经获批用于DME的治疗，现在Regeneron正试图扩大Eylea的应用范围，希望能够获批治疗患DME的糖尿病视网膜病变（DR）患者。 </br>
 
　　新的应用申请基于VIVID-DME和VISTA-DME的三期临床结果，三期临床在862名患者中进行，与安慰剂对照效果明显。这项试验最初目的是检测该药物对DME的治疗效果，主要目标是提高受试者的最佳矫正视力，其次是评估DR患者的视力提高水平。 </br>
 
　　DR患者除非已经发展到DME，否则早期是不需要治疗的，通常DR和DME最终都会通过激光手术治疗，Alimera Sciences在售一种称为Iluvien的埋植剂，据说可以用于DME的治疗，然而Eylea，仅需要注射就可以达到增强视力的效果，不需要进行手术，对患者而言也是减轻痛苦的利好治疗方式。 </br>
 
　　Eylea还被批准用于治疗另外两种适应症，一种是湿性老年性黄斑变性，另一种是视网膜静脉阻塞后黄斑水肿。去年该药物的收益是14亿美元，与12年的8.379亿美元相比增加了68%。Regeneron主要负责美国的销售，而拜耳负责该药品在其它国家的分销工作。直接与Eylea展开激烈竞争的药品是罗氏的Lucentis和Avastin，2013年Avastin的销售额是62.5亿美元，而Lucentis同期的销售额是16.9亿美元。此番FDA授予Eylea补充生物制剂许可证申请的优先审核权将会扩大Regeneron在市场竞争中的优势。 </br></br>
来源：生物谷　
</div>
</p>
<!--糖尿病知识结束--> 



<script src="/diabetes/public/static/js/index.js"></script> 
<script src="/diabetes/public/static/js/login.js"></script> 
<script src="/diabetes/public/static/js/jquery.min.js"></script> 
<script src="/diabetes/public/static/js/bootstrap.min.js"></script>
</body>
</html>