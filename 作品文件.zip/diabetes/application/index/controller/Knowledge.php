<?php
namespace app\index\controller;

use think\View;
use think\Cookie;
use think\Db;   //导入系统数据库类
use think\Controller;  //引入系统控制器类    初始化方法要用

class Knowledge extends Controller
{
    public function knowledge()
    {
        return $this->redirect('Index/index');
    }

    public function myinfo(){
        return $this->redirect('Information/myinfo');
    }

    //退出登录
    public function logout(){
        if(!cookie(null,'username')){
            $this->success('退出成功','Index/index'); 
        }else{
            $this->error('退出失败，请重试');
        }      
    }
    
	public function knowledge1()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge2()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge3()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge4()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge5()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge6()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge7()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function knowledge8()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }
}