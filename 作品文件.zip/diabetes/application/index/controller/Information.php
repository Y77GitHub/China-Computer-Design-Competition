<?php
namespace app\index\controller;

use think\View;
use think\Db;
use think\Cookie;
use think\Controller;  //引入系统控制器类    初始化方法要用
use think\Request;

class Information extends Controller
{
    public function information()
    {
        return $this->redirect('Index/index');
    }
    
    //退出登录
    public function logout(){
        if(!cookie(null,'username')){
            $this->success('退出成功','Index/index'); 
        }else{
            $this->error('退出失败，请重试');
        }    
    }

    public function information1()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information2()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information3()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information4()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information5()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information6()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information7()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information8()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function information9()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function myinfo()
    {
        //把用户信息展示在基本信息里
        $username=cookie('username');
        $data['age']=Db::table('user')->where('username',$username)->value('age');
        $data['height']=Db::table('user')->where('username',$username)->value('height');
        $data['weight']=Db::table('user')->where('username',$username)->value('weight');
        $data['sex']=Db::table('user')->where('username',$username)->value('sex');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }

        //找到用户在record表里的uid的值
        $id=Db::table('user')->where('username',$username)->value('id');

        //把用户信息展示在饮食记录里
        $time1=cookie('time1');
        $data['time1']=$time1;       
        $data['breakfast_images']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('breakfast_images');
        $data['breakfast_record']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('breakfast_record');
        $data['lunch_images']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('lunch_images');
        $data['lunch_record']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('lunch_record');
        $data['dinner_images']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('dinner_images');
        $data['dinner_record']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('dinner_record');
        $data['extra_meal_images']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('extra_meal_images');
        $data['extra_meal_record']=Db::table('record')->where(['time'=>$time1,'uid'=>$id])->value('extra_meal_record');
        cookie(null,'time1');

        //身体指标
        $time2=cookie('time2');
        $data['time2']=$time2;
        $data['breakfast_before']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('breakfast_before');
        $data['breakfast_after']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('breakfast_after');
        $data['lunch_before']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('lunch_before');
        $data['lunch_after']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('lunch_after');
        $data['dinner_before']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('dinner_before');
        $data['dinner_after']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('dinner_after');
        $data['extra_meal_before']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('extra_meal_before');
        $data['extra_meal_after']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('extra_meal_after');
        $data['sleep']=Db::table('record')->where(['time'=>$time2,'uid'=>$id])->value('sleep');
        cookie(null,'time2');

        $this->assign('data',$data);
        return $this->fetch();
    }

    //修改饮食记录
    public function setdiet_record(){
        $redata=input('post.');
        $data['time1']=$redata['time1'];
        if($data['time1']==null){
            return $this->error('日期不能为空');
        }else{
            $time1 = $data['time1'];
            cookie('time1',$time1);
            return  $this->redirect('Information/myinfo');
        }
    }
   
    //修改密码
    public function setpassword(){
        $data=input('post.');
        $redata['password']=$data['password'];
        $redata['repassword']=$data['repassword'];
        $name=cookie('username');
        if($redata!=null){
            if(strlen($data['password'])<6 || strlen($data['password'])>12){
                return $this->error('新密码长度只能在6到12位之间');
            }
            if($redata['password']!=$redata['repassword']){
                return $this->error('两次密码输入不一致，请重新输入');
            }
            
            if(Db::table('user')->where('username',$name)->value('password') == $redata['password']){
                return $this->error('输入的密码与旧密码一致，请重新输入');
            }else if(Db::table('user')->where('username',$name)->update(['password'=>$redata['password']])){
                cookie(null,'username');
                return $this->success('密码修改成功','Index/index');
            }else{
                return $this->error('密码修改不成功，请重新修改');
            }
        }else{
            return $this->error('密码不能为空，请重新输入');
        }
    }

    //修改基本信息
    public function setpeople(){
        $redata=input('post.');
        
        $data['age']=trim($redata['age']);
        $data['height']=trim($redata['height']);
        $data['weight']=trim($redata['weight']);
        $data['sex']=trim($redata['sex']);
        $username=cookie('username');
        $id=Db::table('user')->where('username',$username)->value('id');

        // 获取表单上传文件 例如上传了001.jpg
        $files = request()->file('head_sculpture');
        if($files!=""){
            // 移动到框架应用根目录/public/uploads/ 目录
            $info = $files->move(ROOT_PATH . 'public' . DS . 'head_sculpture'); 
            if($info){
                // 成功上传后 获取上传信息
                $getSaveName=str_replace("\\","/",$info->getSaveName());//把反斜杠(\)替换成斜杠(/) 
                $data['head_sculpture'] = $getSaveName;
            }else{
                // 上传失败获取错误信息
                return $this->error($files->getError());
            }
        }else{
            $data['head_sculpture'] ='head_sculpture.png';
        }
        
        if($data['age']=="" || $data['height']=="" || $data['weight']==""){
            return $this->error('基本信息修改不能为空');
        }
        if(!is_numeric($data['age'])){
                return $this->error('年龄请填入整数');
        }
        if(!is_numeric($data['height'])){
                return $this->error('身高请填入整数或小数');
        }
        if(!is_numeric($data['weight'])){
                return $this->error('体重请填入整数或小数');
        }
        $update=Db::table('user')->where('id',$id)->update($data);
        if($update){
            return $this->success('基本信息修改成功');
        }else{
            return $this->success('基本信息修改不成功，请重新修改');
        }                     
    }

    //修改身体指标
    public function setbody_index(){
        $redata=input('post.');
        $data['time2']=$redata['time2'];
        if($data['time2']==null){
            return $this->error('日期不能为空');
        }else{
            $time2 = $data['time2'];
            cookie('time2',$time2);
            return  $this->redirect('Information/myinfo');
        }
    }
}