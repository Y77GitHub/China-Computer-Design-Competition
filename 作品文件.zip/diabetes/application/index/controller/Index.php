<?php
namespace app\index\controller;

use think\View; 
use think\Cookie;
use think\Db;   //导入系统数据库类
use think\Validate;  //导入自定义验证器
use think\Controller;  //引入系统控制器类    初始化方法要用

class Index extends Controller
{
    public function index()
    {
        $username=cookie('username');
        $data['head_sculpture']=Db::table('user')->where('username',$username)->value('head_sculpture');
        if($data['head_sculpture']==null){
            $data['head_sculpture']='head_sculpture.png';
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    //退出登录
    public function logout(){
        if(!cookie(null,'username')){
            $this->success('退出成功'); 
        }else{
            $this->error('退出失败，请重试');
        }    
    }

    //注册页面
    public function register(){
    	//接受从index页面的register传输过来的值
        $redata=input('post.');
        $data['username']=$redata['username'];
        $data['password']=$redata['password'];

        if($data['username']==null){
            return $this->error('用户名不能为空');
        }
        if(strlen($data['password'])<6 || strlen($data['password'])>12){
            return $this->error('密码长度只能在6到12位之间');
        }
        if($redata['repassword']!=$data['password']){
            return $this->error('两次密码不一致，请重新输入');
        }

        $select=Db::table('user')->where('username',$data['username'])->find();
        if (!$select) {
        //写入数据库
            if (Db::table('user')->insert($data)){
                return $this->success('注册成功');
            } else {
                return $this->error('注册失败，请重新注册');
            }       
        }else{
            return $this->error('用户名已被注册，请重新输入');
        }
    }

    //处理登录的页面传过来的值
    public function login(){
        //接受从login的index页面传输过来的值       
        $data=input('post.');
        $re_data['username']=$data['username'];
        $re_data['password']=$data['password'];
        
        if($re_data['username']=="" || $re_data['password']==""){
            return $this->error('用户名或密码不能为空，请重新输入');
        }

        $select=Db::table('user')->where('username',$re_data['username'])->where('password',$re_data['password'])->find();
        $username = $re_data['username'];
        cookie('username',$username);
        //验证码验证
        $captcha = input('captcha');
        if(!captcha_check($captcha)){
            return $this->error('验证码错误，请重新刷新');
        }else if($select!=null){
            $this->success('登录成功');
        }else{
            return $this->error('用户名或密码错误，请重新输入');
        }  
    }
  
    public function breakfast(){
        $redata=input('post.');
        $data['time']=$redata['time'];
        $data['breakfast_record']=trim($redata['breakfast_record']);
        $data['breakfast_before']=trim($redata['breakfast_before']);
        $data['breakfast_after']=trim($redata['breakfast_after']);
        $name=cookie('username');
        if($name==null){
            return $this->error('请先登录');
        }
        $id=Db::table('user')->where('username',$name)->value('id');
        if($data['time']=="" || $data['breakfast_record']=="" || $data['breakfast_before']=="" || $data['breakfast_after']==""){
            return $this->error('请填入每个数据');
        }
        if(!is_numeric($data['breakfast_before']) && !is_numeric($data['breakfast_after'])){
            return $this->error('血糖含量请填入整数或小数');
        }
        // 获取表单上传文件 例如上传了001.jpg
        $files = request()->file('breakfast_images');
        if($files==null){
                return $this->error('早餐图片不能为空，请重新进行早餐记录');
        }else{
            // 移动到框架应用根目录/public/uploads/ 目录
            $info = $files->move(ROOT_PATH . 'public' . DS . 'breakfast_images'); 
            if($info){
                // 成功上传后 获取上传信息
                $getSaveName=str_replace("\\","/",$info->getSaveName());//把反斜杠(\)替换成斜杠(/) 
                $data['breakfast_images'] = $getSaveName;
            }else{
                // 上传失败获取错误信息
                return $this->error($files->getError());
            }
        }
        if(Db::table('record')->where('uid',$id)->find()==null){
            $re_id=['uid'=>$id];
            Db::table('record')->insert($re_id);
            if(Db::table('record')->where('uid',$id)->update($data)){
                return $this->success('早餐记录成功');
            }else{
                return $this->error('早餐记录错误，请重新记录。');
            }
        }else{
            $retime=Db::table('record')->where('uid',$id)->column('time');
            for($i=0;$i<count($retime);$i++){
                if($retime[$i]==$data['time']){
                    $update=['breakfast_record'=>$data['breakfast_record'],'breakfast_images'=>$data['breakfast_images'],'breakfast_before'=>$data['breakfast_before'],'breakfast_after'=>$data['breakfast_after']];
                    if(Db::table('record')->where(['uid'=>$id,'time'=>$data['time']])->update($update)){
                        return $this->success('早餐记录成功');
                    }else{
                        return $this->error('早餐记录错误，请重新记录。');
                    }
                }
            }                   
            $reupdate=['uid'=>$id,'time'=>$data['time'],'breakfast_record'=>$data['breakfast_record'],'breakfast_images'=>$data['breakfast_images'],'breakfast_before'=>$data['breakfast_before'],'breakfast_after'=>$data['breakfast_after']];
            if(Db::table('record')->insert($reupdate)){
                return $this->success('早餐记录成功');
            }else{
                return $this->error('早餐记录错误，请重新记录。');
            }
        }                          
    }
    
    public function lunch(){
        $redata=input('post.');
        $data['time']=$redata['time'];
        $data['lunch_record']=trim($redata['lunch_record']);
        $data['lunch_before']=trim($redata['lunch_before']);
        $data['lunch_after']=trim($redata['lunch_after']);
        $name=cookie('username');
        if($name==null){
            return $this->error('请先登录');
        }
        $id=Db::table('user')->where('username',$name)->value('id');
        if($data['time']=="" || $data['lunch_record']=="" || $data['lunch_before']=="" || $data['lunch_after']==""){
            return $this->error('请填入每个数据');
        }
        if(!is_numeric($data['lunch_before']) && !is_numeric($data['lunch_after'])){
            return $this->error('血糖含量请填入整数或小数');
        }
        // 获取表单上传文件 例如上传了001.jpg
        $files = request()->file('lunch_images');
        if($files==null){
                return $this->error('午餐图片不能为空，请重新进行午餐记录');
        }else{
            // 移动到框架应用根目录/public/uploads/ 目录
            $info = $files->move(ROOT_PATH . 'public' . DS . 'lunch_images'); 
            if($info){
                // 成功上传后 获取上传信息
                $getSaveName=str_replace("\\","/",$info->getSaveName());//把反斜杠(\)替换成斜杠(/) 
                $data['lunch_images'] = $getSaveName;
            }else{
                // 上传失败获取错误信息
                return $this->error($files->getError());
            }
        }
        if(Db::table('record')->where('uid',$id)->find()==null){
            $re_id=['uid'=>$id];
            Db::table('record')->insert($re_id);
            if(Db::table('record')->where('uid',$id)->update($data)){
                return $this->success('午餐记录成功');
            }else{
                return $this->error('午餐记录错误，请重新记录。');
            }
        }else{
            $retime=Db::table('record')->where('uid',$id)->column('time');
            for($i=0;$i<count($retime);$i++){
                if($retime[$i]==$data['time']){
                    $update=['lunch_record'=>$data['lunch_record'],'lunch_images'=>$data['lunch_images'],'lunch_before'=>$data['lunch_before'],'lunch_after'=>$data['lunch_after']];
                    if(Db::table('record')->where(['uid'=>$id,'time'=>$data['time']])->update($update)){
                        return $this->success('午餐记录成功');
                    }else{
                        return $this->error('午餐记录错误，请重新记录。');
                    }
                }
            }                   
            $reupdate=['uid'=>$id,'time'=>$data['time'],'lunch_record'=>$data['lunch_record'],'lunch_images'=>$data['lunch_images'],'lunch_before'=>$data['lunch_before'],'lunch_after'=>$data['lunch_after']];
            if(Db::table('record')->insert($reupdate)){
                return $this->success('午餐记录成功');
            }else{
                return $this->error('午餐记录错误，请重新记录。');
            }
        }
    }

    public function dinner(){
        $redata=input('post.');
        $data['time']=$redata['time'];
        $data['dinner_record']=trim($redata['dinner_record']);
        $data['dinner_before']=trim($redata['dinner_before']);
        $data['dinner_after']=trim($redata['dinner_after']);
        $name=cookie('username');
        if($name==null){
            return $this->error('请先登录');
        }
        $id=Db::table('user')->where('username',$name)->value('id');
        if($data['time']=="" || $data['dinner_record']=="" || $data['dinner_before']=="" || $data['dinner_after']==""){
            return $this->error('请填入每个数据');
        }
        if(!is_numeric($data['dinner_before']) && !is_numeric($data['dinner_after'])){
            return $this->error('血糖含量请填入整数或小数');
        }
        // 获取表单上传文件 例如上传了001.jpg
        $files = request()->file('dinner_images');
        if($files==null){
                return $this->error('晚餐图片不能为空，请重新进行晚餐记录');
        }else{
            // 移动到框架应用根目录/public/uploads/ 目录
            $info = $files->move(ROOT_PATH . 'public' . DS . 'dinner_images'); 
            if($info){
                // 成功上传后 获取上传信息
                $getSaveName=str_replace("\\","/",$info->getSaveName());//把反斜杠(\)替换成斜杠(/) 
                $data['dinner_images'] = $getSaveName;
            }else{
                // 上传失败获取错误信息
                return $this->error($files->getError());
            }
        }
        if(Db::table('record')->where('uid',$id)->find()==null){
            $re_id=['uid'=>$id];
            Db::table('record')->insert($re_id);
            if(Db::table('record')->where('uid',$id)->update($data)){
                return $this->success('晚餐记录成功');
            }else{
                return $this->error('晚餐记录错误，请重新记录。');
            }
        }else{
            $retime=Db::table('record')->where('uid',$id)->column('time');
            for($i=0;$i<count($retime);$i++){
                if($retime[$i]==$data['time']){
                    $update=['dinner_record'=>$data['dinner_record'],'dinner_images'=>$data['dinner_images'],'dinner_before'=>$data['dinner_before'],'dinner_after'=>$data['dinner_after']];
                    if(Db::table('record')->where(['uid'=>$id,'time'=>$data['time']])->update($update)){
                        return $this->success('晚餐记录成功');
                    }else{
                        return $this->error('晚餐记录错误，请重新记录。');
                    }
                }
            }                   
            $reupdate=['uid'=>$id,'time'=>$data['time'],'dinner_record'=>$data['dinner_record'],'dinner_images'=>$data['dinner_images'],'dinner_before'=>$data['dinner_before'],'dinner_after'=>$data['dinner_after']];
            if(Db::table('record')->insert($reupdate)){
                return $this->success('晚餐记录成功');
            }else{
                return $this->error('晚餐记录错误，请重新记录。');
            }
        }
    }

    public function extra_meal(){
        $data=input('post.');
        $data['time']=$redata['time'];
        $data['extra_meal_record']=trim($redata['extra_meal_record']);
        $data['extra_meal_before']=trim($redata['extra_meal_before']);
        $data['extra_meal_after']=trim($redata['extra_meal_after']);
        $name=cookie('username');
        if($name==null){
            return $this->error('请先登录');
        }
        $id=Db::table('user')->where('username',$name)->value('id');
        if($data['time']=="" || $data['extra_meal_record']=="" || $data['extra_meal_before']=="" || $data['extra_meal_after']==""){
            return $this->error('请填入每个数据');
        }
        if(!is_numeric($data['extra_meal_before']) && !is_numeric($data['extra_meal_after'])){
            return $this->error('血糖含量请填入整数或小数');
        }
        // 获取表单上传文件 例如上传了001.jpg
        $files = request()->file('extra_meal_images');
        if($files==null){
                return $this->error('加餐图片不能为空，请重新进行加餐记录');
        }else{
            // 移动到框架应用根目录/public/uploads/ 目录
            $info = $files->move(ROOT_PATH . 'public' . DS . 'extra_meal_images'); 
            if($info){
                // 成功上传后 获取上传信息
                $getSaveName=str_replace("\\","/",$info->getSaveName());//把反斜杠(\)替换成斜杠(/) 
                $data['extra_meal_images'] = $getSaveName;
            }else{
                // 上传失败获取错误信息
                return $this->error($files->getError());
            }
        }
        if(Db::table('record')->where('uid',$id)->find()==null){
            $re_id=['uid'=>$id];
            Db::table('record')->insert($re_id);
            if(Db::table('record')->where('uid',$id)->update($data)){
                return $this->success('加餐记录成功');
            }else{
                return $this->error('加餐记录错误，请重新记录。');
            }
        }else{
            $retime=Db::table('record')->where('uid',$id)->column('time');
            for($i=0;$i<count($retime);$i++){
                if($retime[$i]==$data['time']){
                    $update=['extra_meal_record'=>$data['extra_meal_record'],'extra_meal_images'=>$data['extra_meal_images'],'extra_meal_before'=>$data['extra_meal_before'],'extra_meal_after'=>$data['extra_meal_after']];
                    if(Db::table('record')->where(['uid'=>$id,'time'=>$data['time']])->update($update)){
                        return $this->success('加餐记录成功');
                    }else{
                        return $this->error('加餐记录错误，请重新记录。');
                    }
                }
            }                   
            $reupdate=['uid'=>$id,'time'=>$data['time'],'extra_meal_record'=>$data['extra_meal_record'],'extra_meal_images'=>$data['extra_meal_images'],'extra_meal_before'=>$data['extra_meal_before'],'extra_meal_after'=>$data['extra_meal_after']];
            if(Db::table('record')->insert($reupdate)){
                return $this->success('加餐记录成功');
            }else{
                return $this->error('加餐记录错误，请重新记录。');
            }
        }
    }

    public function knowledge1(){
        return $this->redirect('Knowledge/knowledge1');
    }

    public function knowledge2(){
        return $this->redirect('Knowledge/knowledge2');
    }

    public function knowledge3(){
        return $this->redirect('Knowledge/knowledge3');
    }

    public function knowledge4(){
        return $this->redirect('Knowledge/knowledge4');
    }

    public function knowledge5(){
        return $this->redirect('Knowledge/knowledge5');
    }

    public function knowledge6(){
        return $this->redirect('Knowledge/knowledge6');
    }

    public function knowledge7(){
        return $this->redirect('Knowledge/knowledge1');
    }

    public function knowledge8(){
        return $this->redirect('Knowledge/knowledge7');
    }

    public function information1(){
        return $this->redirect('Information/information1');
    }

    public function information2(){
        return $this->redirect('Information/information2');
    }

    public function information3(){
        return $this->redirect('Information/information3');
    }

    public function information4(){
        return $this->redirect('Information/information4');
    }

    public function information5(){
        return $this->redirect('Information/information5');
    }

    public function information6(){
        return $this->redirect('Information/information6');
    }

    public function information7(){
        return $this->redirect('Information/information7');
    }

    public function information8(){
        return $this->redirect('Information/information8');
    }

    public function information9(){
        return $this->redirect('Information/information9');
    }

    public function myinfo(){
        return $this->redirect('Information/myinfo');
    }

    public function basicmetabolismcalculation(){
        return $this->redirect('Tool/basicmetabolismcalculation');
    }

    public function bloodsugarrecord(){
        return $this->redirect('Tool/bloodsugarrecord');
    }

    public function countbmi(){
        return $this->redirect('Tool/countbmi');
    }

    public function healthyweightscope(){
        return $this->redirect('Tool/healthyweightscope');
    }

}
