/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : diabetes

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2019-04-30 17:19:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `record`
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `uid` int(100) DEFAULT NULL,
  `time` date DEFAULT NULL,
  `breakfast_record` text,
  `breakfast_before` decimal(5,2) DEFAULT NULL,
  `breakfast_after` decimal(5,2) DEFAULT NULL,
  `breakfast_images` varchar(255) DEFAULT NULL,
  `lunch_record` text,
  `lunch_before` decimal(5,2) DEFAULT NULL,
  `lunch_after` decimal(5,2) DEFAULT NULL,
  `lunch_images` varchar(255) DEFAULT NULL,
  `dinner_record` text,
  `dinner_before` decimal(5,2) DEFAULT NULL,
  `dinner_after` decimal(5,2) DEFAULT NULL,
  `dinner_images` varchar(255) DEFAULT NULL,
  `extra_meal_record` text,
  `extra_meal_before` decimal(5,2) DEFAULT NULL,
  `extra_meal_after` decimal(5,2) DEFAULT NULL,
  `extra_meal_images` varchar(255) DEFAULT NULL,
  `sleep` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of record
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `height` int(3) DEFAULT NULL,
  `weight` int(3) DEFAULT NULL,
  `head_sculpture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
